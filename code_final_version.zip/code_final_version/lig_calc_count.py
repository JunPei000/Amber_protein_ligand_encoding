#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 10:31:35 2019

@author: peijun
"""

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 10:50:30 2019

@author: peijun
"""

from encode_amber_info_finder import lig_info
from encode_amber_info_finder import angle_finder
from encode_amber_info_finder import dihedral_finder
from encode_amber_info_finder import oop_finder
from encode_amber_info_finder import vdw_finder
from encode_amber_info_finder import decoy_lig_generator
from encode_amber_info_finder import atom_info_protein
from encode_amber_info_finder import protein_prep
from energy_calc_interaction_count import bond_calc
from energy_calc_interaction_count import angle_calc
from energy_calc_interaction_count import dihedral_calc
from energy_calc_interaction_count import oop_calc
from energy_calc_interaction_count import vdw_eel_calc
from energy_calc_interaction_count import inter_calc
from CASF_seperate import ligfile_finder
from insert import insert
import json
import os

direct1 = '/mnt/home/peijun/Documents/PL_amber/CASF2016/all_opt_ligands_resp/resp_all_mol2/'
directp = '/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/coreset/'
problems = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy', '4dli', '5tmn', '3qgy']
test = ['2wer', '2xys', '2zy1', '3ary', '3b68', '3dx2', '3pww', '3up2', '3utu', '4abg', '4agp', '4eo8', '4f9w', '4kz6', '4qac', '5c2h']
filenames = [i for i in os.listdir(direct1) if '_ligand_opt_resp_use.mol2' in i and i[:4] not in problems and '.swp' not in i]

#foldernames =['1ydr']
for filename in filenames:
    #if filename[:4] != '1bcu':
    #    continue
    dic_final = {}
    print (filename[:4], filenames.index(filename))
    
    direct2 = '/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/decoys_docking/'
    dic_decoy = {}
    dic_decoy = ligfile_finder(direct2, filename[:4])
    
    ligfile = open(direct1+filename, 'r').readlines()
    dic_lig = {}; dic_bond = {}; bond_list = []; dic_angle = {}; angle_list = []; dic_dihedral = {}; dihedral_list = []; oop_list = []; vdw_list = []
    dic_lig, dic_bond, bond_list = lig_info(ligfile)
    dic_angle, angle_list = angle_finder(dic_bond, bond_list)
    dic_dihedral, dihedral_list = dihedral_finder(dic_bond, angle_list)
    oop_list = oop_finder(dic_bond, angle_list)
    vdw_list = vdw_finder(dic_lig, dic_bond, dic_angle, dic_dihedral)
    
    dic_bond_energy = {}; dic_angle_energy = {}; dic_dihedral_energy = {}; dic_oop_energy = {}; dic_nonb_energy = {}; dic_inter_energy = {}
    dic_bond_energy = bond_calc(dic_lig, bond_list)
    dic_angle_energy = angle_calc(dic_lig, angle_list)
    dic_dihedral_energy = dihedral_calc(dic_lig, dihedral_list, angle_list)
    dic_oop_energy = oop_calc(dic_lig, oop_list, filename[:4])
    dic_nonb_energy = vdw_eel_calc(dic_lig, vdw_list)
    
    direct3 = directp+filename[:4]+'/'
    insert(direct3, direct3, filename[:4]+'_protein.pdb')
    protein_file = open(direct3+'inserted_'+filename[:4]+'_protein.pdb', 'r').readlines()
    protein_file = protein_prep(protein_file)
    dic_pro = atom_info_protein(protein_file)
    dic_inter_energy = inter_calc(dic_lig, dic_pro)
    
    dic_final['native'] = {}
    dic_final['native']['bond'] = {}
    dic_final['native']['angle'] = {}
    dic_final['native']['torsion'] = {}
    dic_final['native']['nonb'] = {}
    dic_final['native']['inter'] = {}
    
    dic_final['native']['bond'] = dic_bond_energy
    dic_final['native']['angle'] = dic_angle_energy
    dic_final['native']['inter'] = dic_inter_energy
    
    for key in dic_dihedral_energy:
        if key in dic_final['native']['torsion']:
            print ('Same dihedral in dic_final[native][torsion]!', key)
        dic_final['native']['torsion'][key] = 0
        dic_final['native']['torsion'][key] += dic_dihedral_energy[key]['dihedral']
        dic_final['native']['torsion'][key] += dic_dihedral_energy[key]['14_vdw']
        dic_final['native']['torsion'][key] += dic_dihedral_energy[key]['14_eel']
    
    for key in dic_oop_energy:
        if key in dic_final['native']['torsion']:
            print ('Same oop in dic_final[native][torsion]!', key)
        dic_final['native']['torsion'][key] = 0
        dic_final['native']['torsion'][key] += dic_oop_energy[key]
    
    for key in dic_nonb_energy:
        if key in dic_final['native']['nonb']:
            print ('Same nonb in dic_final[native][nonb]!', key)
        dic_final['native']['nonb'][key] = 0
        dic_final['native']['nonb'][key] += dic_nonb_energy[key]['vdw']
        dic_final['native']['nonb'][key] += dic_nonb_energy[key]['eel']
        
        
    for key in dic_decoy:
        decoy_file = dic_decoy[key]
        decoy_lig = lig_info(decoy_file)[0]
        decoy_lig = decoy_lig_generator(decoy_lig, dic_lig)
        decoy_bond_energy = {}; decoy_angle_energy = {}; decoy_dihedral_energy = {}; decoy_oop_energy = {}; decoy_nonb_energy = {}; decoy_inter_energy = {}
        decoy_bond_energy = bond_calc(decoy_lig, bond_list)
        decoy_angle_energy = angle_calc(decoy_lig, angle_list)
        decoy_dihedral_energy = dihedral_calc(decoy_lig, dihedral_list, angle_list)
        decoy_oop_energy = oop_calc(decoy_lig, oop_list, filename[:4])
        decoy_nonb_energy = vdw_eel_calc(decoy_lig, vdw_list)
        decoy_inter_energy = inter_calc(decoy_lig, dic_pro)
        
        if key in dic_final:
            print ('Same decoy file exists twice in dic_final!', key)
        dic_final[key] = {}
        dic_final[key]['bond'] = {}
        dic_final[key]['angle'] = {}
        dic_final[key]['torsion'] = {}
        dic_final[key]['nonb'] = {}
        dic_final[key]['inter'] = {}
    
        dic_final[key]['bond'] = decoy_bond_energy
        dic_final[key]['angle'] = decoy_angle_energy
        dic_final[key]['inter'] = decoy_inter_energy
        
        for key1 in decoy_dihedral_energy:
            if key1 in dic_final[key]['torsion']:
                print ('Same dihedral in dic_final[key][torsion]!', key1)
            dic_final[key]['torsion'][key1] = 0
            dic_final[key]['torsion'][key1] += decoy_dihedral_energy[key1]['dihedral']
            dic_final[key]['torsion'][key1] += decoy_dihedral_energy[key1]['14_vdw']
            dic_final[key]['torsion'][key1] += decoy_dihedral_energy[key1]['14_eel']
    
        for key1 in decoy_oop_energy:
            if key1 in dic_final[key]['torsion']:
                print ('Same oop in dic_final[key][torsion]!', key1)
            dic_final[key]['torsion'][key1] = 0
            dic_final[key]['torsion'][key1] += decoy_oop_energy[key1]
    
        for key1 in decoy_nonb_energy:
            if key1 in dic_final[key]['nonb']:
                print ('Same nonb in dic_final[key][nonb]!', key1)
            dic_final[key]['nonb'][key1] = 0
            dic_final[key]['nonb'][key1] += decoy_nonb_energy[key1]['vdw']
            dic_final[key]['nonb'][key1] += decoy_nonb_energy[key1]['eel']
    newfile = open('/mnt/home/peijun/Documents/PL_amber/orig_results/resp/cutoff_10_inter_count/'+filename[:4]+'_all_info.json', 'w')
    json.dump(dic_final, newfile)
    newfile.close()
        
    
    
    
    
    
    
    
