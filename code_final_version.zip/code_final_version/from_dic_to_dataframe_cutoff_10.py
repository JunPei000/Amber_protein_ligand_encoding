import os
import json
import pandas as pd

#direct1 = '/mnt/home/peijun/Documents/PL_amber/orig_results/resp/cutoff_10/'
direct1 = '/mnt/home/peijun/Documents/PL_amber/orig_results/resp/cutoff_10_inter_count/'
filenames = [i for i in os.listdir(direct1) if '.json' in i]

## generate the template
#bond = []; angle = []; torsion = []; nonb = []; inter = []
#for filename in filenames:
#    #print (filename)
#    fp1 = open(direct1+filename, 'r')
#    dic1 = {}
#    dic1 = json.load(fp1)
#    if 'native' not in dic1:
#        print ('Missing native structure!', filename)
#    for k in dic1:
#        for key in dic1[k]['bond']:
#            if key+'b' not in bond:
#                bond.append(key+'b')
#        for key in dic1[k]['angle']:
#            if key+'a' not in angle:
#                angle.append(key+'a')
#        for key in dic1[k]['torsion']:
#            if len(key) >= 4:
#                if key+'t' not in torsion:
#                    torsion.append(key+'t')
#            else:
#                if key+'o' not in torsion:
#                    torsion.append(key+'o')
#        for key in dic1[k]['nonb']:
#            if key+'n' not in nonb:
#                nonb.append(key+'n')
#        for key in dic1[k]['inter']:
#            if key+'i' not in inter:
#                inter.append(key+'i')

#print (len(bond), len(angle), len(torsion), len(nonb), len(inter))

#template_df = pd.DataFrame()
#for b in bond:
#    template_df.loc[0, b] = 1
#for a in angle:
#    template_df.loc[0, a] = 1
#for t in torsion:
#    template_df.loc[0, t] = 1
#for n in nonb:
#    template_df.loc[0, n] = 1
#for i in inter:
#    template_df.loc[0, i] = 1
#print (template_df)
#
#newfile = open('/mnt/home/peijun/Documents/PL_amber/template/cutoff_10.csv', 'w')
#template_df.to_csv(newfile)
#newfile.close()

### Based on the template, generate dfs for each file

template = pd.read_csv('/mnt/home/peijun/Documents/PL_amber/template/cutoff_10.csv')
for filename in filenames:
    print (filename)
    #if filenames.index(filename) < 112:
    #    continue   
    fp1 = open(direct1+filename, 'r')
    dic1 = {}
    dic1 = json.load(fp1)
    df_f = pd.read_csv('/mnt/home/peijun/Documents/PL_amber/template/cutoff_10.csv')
    df_f.loc[0] = 0
    dic2 = {}
    count = 0
    for key in dic1:
        #print (key)
        df_f.loc[count, 'structure'] = key
        dic2[key] = {}
        for b in dic1[key]['bond']:
            dic2[key][b+'b'] = dic1[key]['bond'][b]
            if b+'b' not in df_f.columns:
                print ('Missing bond!', b+'b')
            df_f.loc[count, b+'b'] = dic1[key]['bond'][b]
        for a in dic1[key]['angle']:
            dic2[key][a+'a'] = dic1[key]['angle'][a]
            if a+'a' not in df_f.columns:
                print ('Missing angle!', a+'a')
            df_f.loc[count, a+'a'] = dic1[key]['angle'][a]
        for t in dic1[key]['torsion']:
            if len(t) >= 4:
                dic2[key][t+'t'] = dic1[key]['torsion'][t]
                if t+'t' not in df_f.columns:
                    print ('Missing dihedral!', t+'t')
                df_f.loc[count, t+'t'] = dic1[key]['torsion'][t]
            else:
                dic2[key][t+'o'] = dic1[key]['torsion'][t]
                if t+'o' not in df_f.columns:
                    print ('Missing oop!', t+'o')
                df_f.loc[count, t+'o'] = dic1[key]['torsion'][t]
        for n in dic1[key]['nonb']:
            dic2[key][n+'n'] = dic1[key]['nonb'][n]
            if n+'n' not in df_f.columns:
                print ('Missing nonb!', n+'n')
            #print (dic1[key]['nonb'][n])
            df_f.loc[count, n+'n'] = dic1[key]['nonb'][n]
        for i in dic1[key]['inter']:
            dic2[key][i+'i'] = dic1[key]['inter'][i]
            if i+'i' not in df_f.columns:
                print ('Missing inter!', i+'i')
            #print (dic1[key]['inter'][i])
            df_f.loc[count, i+'i'] = dic1[key]['inter'][i]['vdw']+dic1[key]['inter'][i]['eel']
        count += 1
    df_f = df_f.fillna(0)
    print (df_f)
    newfile = open('/mnt/home/peijun/Documents/PL_amber/data_frame/resp/cutoff_10_inter_count/'+filename.replace('json', 'csv'), 'w')
    df_f.to_csv(newfile)
    newfile.close()        
#    for key in dic2:
#        for key1 in dic2[key]:
#            if key1 not in template.columns:
#                print (filename, key, key1)
    
        








