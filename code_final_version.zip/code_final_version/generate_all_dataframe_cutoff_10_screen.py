import os
import pandas as pd
import json

direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/resp/screen/cutoff_10_modified/'
foldernames = [i for i in os.listdir(direct1) if os.path.isdir(direct1+i)]

fp1 = open('/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/screening_target_info.json', 'r')
dic1 = {}
dic1 = json.load(fp1)

native_temp = pd.read_csv(direct1+'native_info.csv')
print (native_temp)

for foldername in foldernames:
    print (foldername)
    direct2 = direct1+foldername+'/'
    for key in dic1[foldername]:
        if key != '1':
            continue
        direct3 = direct2+foldername+'_'+key+'/'
        if not os.path.isdir(direct3):
            os.makedirs(direct3)
        filenames = [i for i in os.listdir(direct2) if '.csv' in i and '.swp' not in i]
        for filename in filenames:
            pd1 = pd.read_csv(direct2+filename)
            print (pd1)
            final_df = pd.DataFrame(columns = pd1.columns, index = pd1.index)
            native_line = native_temp.loc[native_temp['structure'] == foldername]
            #print (native_line)
            native = pd.DataFrame(columns = pd1.columns, index = pd1.index)
            native.loc[native.index, :] = native_line.values
            #print (native)
            df1 = pd.DataFrame(columns = pd1.columns, index = pd1.index)
            df2 = pd.DataFrame(columns = pd1.columns, index = pd1.index)
            df1 = pd1.drop(['structure'], axis=1).sub(native.drop(['structure'], axis=1))
            df2 = native.drop(['structure'], axis=1).sub(pd1.drop(['structure'], axis=1))
            df1['structure'] = pd1['structure']+'_111'
            df2['structure'] = pd1['structure']+'_000'
            final_df = pd.concat([df1, df2]).reset_index(drop=True)
            print (final_df)
            newfile = open(direct3+filename, 'w')
            final_df = final_df.fillna(0)
            final_df.to_csv(newfile)
            newfile.close()

