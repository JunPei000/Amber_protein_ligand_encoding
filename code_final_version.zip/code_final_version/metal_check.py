#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 15:15:14 2019

@author: peijun
"""

import os
import json
from insert import insert
from encode_amber_info_finder import atom_info_protein
from encode_amber_info_finder import protein_prep
from energy_calc import metal_checker

direct1 = '/Users/peijun/Documents/amber_PL_ML/CASF2016/all_opt_ligands_resp/resp_all_mol2/'
directp = '/Users/peijun/Documents/amber_PL_ML/CASF-2016_orig/coreset/'
problems = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy', '4dli', '5tmn', '3qgy']
test = ['2wer', '2xys', '2zy1', '3ary', '3b68', '3dx2', '3pww', '3up2', '3utu', '4abg', '4agp', '4eo8', '4f9w', '4kz6', '4qac', '5c2h']
filenames = [i for i in os.listdir(direct1) if '_ligand_opt_resp_use.mol2' in i and i[:4] not in problems and '.swp' not in i]

#foldernames =['1ydr']
metal = ['LI', 'NA', 'K', 'RB', 'CS', 'FR', 'BE', 'MG', 'CA', 'SR', 'BA', 'RA', 'SC', 'Y', 'TI', 
             'ZR', 'HF', 'V', 'NB', 'TA', 'CR', 'MO', 'W', 'MN', 'TC', 'RE', 'FE', 'RU', 'OS', 'CO', 
             'RH', 'IR', 'NI', 'PD', 'PT', 'CU', 'AG', 'AU', 'ZN', 'CD', 'HG', 'AL', 'GA', 'IN', 'TL', 
             'GE', 'SN', 'PB', 'SB', 'BI', 'PO']
C = 0
for filename in filenames:
    dic_final = {}
    #print (filename[:4], filenames.index(filename))
    
    ligfile = open(direct1+filename, 'r').readlines()
    dic_lig = {}; dic_bond = {}; bond_list = []; dic_angle = {}; angle_list = []; dic_dihedral = {}; dihedral_list = []; oop_list = []; vdw_list = []
    dic_lig, dic_bond, bond_list = lig_info(ligfile)
    
    insert(directp+filename[:4]+'/', directp+filename[:4]+'/', filename[:4]+'_pocket.pdb')
    protein_file = open(directp+filename[:4]+'/inserted_'+filename[:4]+'_pocket.pdb', 'r').readlines()
    for line in protein_file:
        newlist = []
        newlist = line.split()
        #print newlist
        if newlist[0] == 'HETATM' and newlist[2] in metal:
            print filename[:4]
            C += 1
            