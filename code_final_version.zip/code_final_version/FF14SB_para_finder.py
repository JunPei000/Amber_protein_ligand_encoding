#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 10:39:49 2019

@author: peijun
"""

import os
import json

fp1 = open('/Users/peijun/Documents/mlproject_mac/code/AMBER/ff14/ff14-write_f.txt', 'r').readlines()
dicf = {}
for line in fp1:
    newlist = []
    newlist = line.split()
    newkey = newlist[1]+'-'+newlist[3]
    if newkey in dicf:
        print ('Error! Same atom exists twice in fp1!', newkey)
    dicf[newkey] = {}
    dicf[newkey]['amber_type'] = newlist[2]
    dicf[newkey]['charge'] = round(float(newlist[4]), 4)
    dicf[newkey]['Rmin'] = round(float(newlist[5]), 4)
    dicf[newkey]['epsilon'] = round(float(newlist[6]), 4)
newfile = open('/Users/peijun/Documents/amber_PL_ML/code/ff14sb_para.json', 'w')
json.dump(dicf, newfile)
newfile.close()
