from __future__ import division
import os
import pandas as pd
import json

### load the org dataframe

direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/am1bcc/cutoff_10/'
filenames = [i for i in os.listdir(direct1) if '.csv' in i]
dic_rmsd = {}
rmsd_file = open('/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/rmsd_info.json', 'r')
dic_rmsd = json.load(rmsd_file)
problems = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy', '4dli', '5tmn', '3qgy']

for filename in filenames:
    print (filename)
    df_org = pd.read_csv(direct1+filename)
    df_final = pd.DataFrame(columns=df_org.columns)
    sysname = filename.replace('_all_info.csv', '')
    if sysname in problems:
        continue
    if sysname not in dic_rmsd:
        continue
    fst_name = dic_rmsd[sysname]['1st']['sysname']
    if '2nd' not in dic_rmsd[sysname]:
        continue
    snd_name = dic_rmsd[sysname]['2nd']['sysname']
    if '3rd' not in dic_rmsd[sysname]:
        continue
    trd_name = dic_rmsd[sysname]['3rd']['sysname']
    if 'others' not in dic_rmsd[sysname]:
        continue
    other_names = []
    other_names = dic_rmsd[sysname]['others']['sysname']
    count = 0
    for row in df_org.index:
        if df_org.loc[row, 'structure'] == 'native':
            continue
        if df_org.loc[row, 'structure'] == fst_name:
            continue
        if df_org.loc[row, 'structure'] == snd_name:
            continue
       # if df_org.loc[row, 'structure'] == trd_name:
       #     continue
       # if df_org.loc[row, 'structure'] in other_names:
       #     continue
        for i in range(1):
            one_y = df_org.loc[row, 'structure']+'_ligo'+str(i)+'_111'
            zero_y = df_org.loc[row, 'structure']+'_ligo'+str(i)+'_000'
            df_final.loc[count,'structure'] = one_y
            df_final.loc[count+1, 'structure'] = zero_y
            df_final.loc[count, [i for i in df_final.columns if i != 'structure']] = df_org.loc[row, [i for i in df_org.columns if i != 'structure']].values - df_org.loc[df_org['structure'] == snd_name, [i for i in df_org.columns if i != 'structure']].values
            df_final.loc[count+1, [i for i in df_final.columns if i != 'structure']] = df_org.loc[df_org['structure'] == snd_name, [i for i in df_org.columns if i != 'structure']].values - df_org.loc[row, [i for i in df_org.columns if i != 'structure']].values
            count += 2
    if len(df_final.index) != 2*(len(df_org)-3):
        print ('error!')
    #print (df_final)
    newfile = open('/mnt/home/peijun/Documents/PL_amber/data_frame/am1bcc/final_cutoff_10_with_lig2/'+filename, 'w')
    df_final.to_csv(newfile)
    newfile.close()
    #print (df_final)
    #break
    #print (df_org.loc[df_org['structure'] == 'native'])
    #print (df_org.loc[df_org['structure'] == 'native', [i for i in df_org.columns if i != 'structure']])




