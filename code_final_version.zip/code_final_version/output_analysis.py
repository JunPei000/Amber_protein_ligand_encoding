from __future__ import division
import os

direct1 = '/mnt/home/peijun/Documents/PL_amber/jobs/output/'
filenames = [i for i in os.listdir(direct1) if 'rf_with_grid_search_with_metalion_without_ba_with_top_500_lig3.' in i and '.o' in i and '.swp' not in i]
filenames = sorted(filenames)

for filename in filenames:
    print (filename)
    fp1 = open(direct1+filename, 'r').readlines()
    if len(fp1) <= 700:
        continue
    ind1 = 0; ind2 = 0
    ind1 = fp1.index('native ranking :\n')
    ind2 = fp1.index('1st decoy rmsd :\n')
    rank = []; RMSD = []
    for line in fp1:
        if 'Best Training score:' in line:
            newlist = []
            newlist = line.split()
            print (newlist[-1])
    for line in fp1:
        if 'Testing accuracy:' in line:
            newlist = []
            newlist = line.split()
            print (newlist[-1])
    for i in range(ind1+2, ind2):
        r = 0
        r = int(fp1[i].replace('\n', ''))
        rank.append(r)
    for i in range(ind2+2, len(fp1)):
        R = 0
        R = round(float(fp1[i].replace('\n', '')), 2)
        RMSD.append(R)
    print (sum(rank)/len(rank))
    print (sum(RMSD)/len(RMSD))
