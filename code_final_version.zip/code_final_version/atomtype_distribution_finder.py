import os
import pandas as pd
import random

fp1 = open('/Users/peijun/Documents/amber_PL_ML/results/otherdata/atomtype_distribution.txt', 'r').readlines()
pd1 = pd.DataFrame()
row = 0
for line in fp1:
    line = line.replace('\n', '').replace('(', '').replace(')', '').replace('[', '').replace(']', '')
    newlist = []
    newlist = line.split(',')
    sysname = newlist[0].replace('_ligand_opt_resp_use.mol2', '')
    pd1.loc[row, 'sysname'] = sysname
    for i in range(2, len(newlist)):
        pd1.loc[row, newlist[i]] = 1
    row += 1
pd1 = pd1.fillna(0)
print (pd1)

a = 0
pre_cc = [12, 76, 106, 121, 229, 234, 235, 254]
while a == 0:
    ccs = random.sample([i for i in range(285) if i not in pre_cc], 17)
    temp_cc = pre_cc+ccs
    temp_re = pd1.loc[temp_cc]
    temp_re.loc['sum'] = temp_re[[c for c in temp_re.columns if c != 'sysname']].sum(axis=0)
    count = 0
    for column in temp_re.columns:
        if temp_re.loc['sum', column] == 0:
            count = 1
            break
    if count == 0:
        a = 1
print (temp_cc)
        
    
    
    
    
    
    
