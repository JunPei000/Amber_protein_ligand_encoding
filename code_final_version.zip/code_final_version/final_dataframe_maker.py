from __future__ import division
import os
import pandas as pd


### load the org dataframe

direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/am1bcc/cutoff_10/'
filenames = [i for i in os.listdir(direct1) if '.csv' in i]

for filename in filenames:
    df_org = pd.read_csv(direct1+filename)
    df_final = pd.DataFrame(columns=df_org.columns)
    count = 0
    print (df_final)
    for row in df_org.index:
        if df_org.loc[row, 'structure'] == 'native':
            continue
        one_y = df_org.loc[row, 'structure']+'111'
        zero_y = df_org.loc[row, 'structure']+'000'
        
        df_final.loc[count,'structure'] = one_y
        df_final.loc[count+1, 'structure'] = zero_y
        df_final.loc[count, [i for i in df_final.columns if i != 'structure']] = df_org.loc[row, [i for i in df_org.columns if i != 'structure']].values - df_org.loc[df_org['structure'] == 'native', [i for i in df_org.columns if i != 'structure']].values
        df_final.loc[count+1, [i for i in df_final.columns if i != 'structure']] = df_org.loc[df_org['structure'] == 'native', [i for i in df_org.columns if i != 'structure']].values - df_org.loc[row, [i for i in df_org.columns if i != 'structure']].values
        count += 2
    print (df_final)
    print (df_org)
    newfile = open('/mnt/home/peijun/Documents/PL_amber/data_frame/am1bcc/final_cutoff_10/'+filename, 'w')
    df_final.to_csv(newfile)
    newfile.close()
    #print (df_org.loc[df_org['structure'] == 'native'])
    #print (df_org.loc[df_org['structure'] == 'native', [i for i in df_org.columns if i != 'structure']])




