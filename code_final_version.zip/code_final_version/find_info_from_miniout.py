#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 12:51:54 2019

@author: peijun
"""

import os

sysname = '1c5z'
fp1 = open('/Users/peijun/Documents/amber_PL_ML/energies_resp/'+sysname+'/dihedral_info', 'r').readlines()
for line in fp1:
    line = line.replace('(', ' ').replace(')', ' ').replace('M', ' ')
    newlist = line.split()
    if len(newlist) <2:
        continue
    if newlist[0] == 'I':
        continue
    if len(newlist) != 19 or '_' in line:
        continue
    
    newline = '-'.join([newlist[2], newlist[5], newlist[8], newlist[11]])+'   '+newlist[-2]+'   '+newlist[-1]
    print newline
    
    