#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 13:26:40 2019

@author: peijun
"""

import os
from encode_amber_info_finder import lig_info
from encode_amber_info_finder import angle_finder
from encode_amber_info_finder import dihedral_finder
from encode_amber_info_finder import oop_finder
from encode_amber_info_finder import vdw_finder
from encode_amber_info_finder import atom_info_protein
from encode_amber_info_finder import protein_prep
from energy_calc import bond_calc
from energy_calc import angle_calc
from energy_calc import dihedral_calc
from energy_calc import oop_calc
from energy_calc import vdw_eel_calc
from energy_calc import inter_calc
from insert import insert

ligfile = open('/Users/peijun/Documents/amber_PL_ML/inter_test/1h23_ligand_resp/1h23_ligand_opt_resp_use.mol2', 'r').readlines()
dic_lig = lig_info(ligfile)[0]
insert('/Users/peijun/Documents/amber_PL_ML/inter_test/', '/Users/peijun/Documents/amber_PL_ML/inter_test/', 'ALA_protein.pdb')
protein_file = open('/Users/peijun/Documents/amber_PL_ML/inter_test/inserted_ALA_protein.pdb', 'r').readlines()
protein_file.append('END\n')
protein_file = protein_prep(protein_file)
dic_pro = atom_info_protein(protein_file)
dic_inter_energy = inter_calc(dic_lig, dic_pro)
    
test_vdw_inter = 0; test_eel_inter = 0
    
for key in dic_inter_energy:
    test_vdw_inter += dic_inter_energy[key]['vdw']
    test_eel_inter += dic_inter_energy[key]['eel']
print test_vdw_inter, round(test_eel_inter, 4)