#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 14:22:09 2019

@author: peijun
"""

import os
import json

def get_connect(lfile):
    ind1 = 0; ind2 = 0
    ind1 = lfile.index('@<TRIPOS>BOND\n')
    ind2 = lfile.index('@<TRIPOS>SUBSTRUCTURE\n')
    dic_c = {}
    for i in range(ind1+1, ind2):
        newlist = []
        newlist = lfile[i].split()
        if newlist[1] not in dic_c:
            dic_c[newlist[1]] = []
        dic_c[newlist[1]].append(newlist[2])
        if newlist[2] not in dic_c:
            dic_c[newlist[2]] = []
        dic_c[newlist[2]].append(newlist[1])
    for key in dic_c:
        for n in dic_c[key]:
            if dic_c[key].count(n) != 1:
                print ('error! Please check bond info for atom number: ', key)
    return dic_c

def get_atominfo(lfile):
    ind1 = 0; ind2 = 0
    ind1 = lfile.index('@<TRIPOS>ATOM\n')
    ind2 = lfile.index('@<TRIPOS>BOND\n')
    dic1 = {}
    for i in range(ind1+1, ind2):
        newlist = []
        newlist = lfile[i].split()
        if newlist[5] == 'cc':
            newlist[5] = 'cd'
        if newlist[5] == 'ce':
            newlist[5] = 'cf'
        if newlist[5] == 'cg':
            newlist[5] = 'ch'
        if newlist[5] == 'cp':
            newlist[5] = 'cq'
        if newlist[5] == 'nc':
            newlist[5] = 'nd'
        if newlist[5] == 'ne':
            newlist[5] = 'nf'
        if newlist[5] == 'pc':
            newlist[5] = 'pd'
        if newlist[5] == 'pe':
            newlist[5] = 'pf'
        if newlist[0] in dic1:
            print ('error! Same atom exists! Please check atom number: ', newlist[0])
        dic1[newlist[0]] = newlist[5]
    return dic1

def get_chemical_environment(dic_c, dic_atominfo):
    dic_f = {}
    for key in dic_c:
        cont = []
        cont = [dic_atominfo[i] for i in dic_c[key]]
        if dic_atominfo[key] not in dic_f:
            dic_f[dic_atominfo[key]] = []
        if sorted(cont) not in dic_f[dic_atominfo[key]]:
            dic_f[dic_atominfo[key]].append(sorted(cont))
    return dic_f

def combine_dics(dic_total, dic_f):
    for key in dic_f:
        if key not in dic_total:
            dic_total[key] = []
        for m in dic_f[key]:
            if m not in dic_total[key]:
                dic_total[key].append(m)
    return dic_total

direct1 = '/Users/peijun/Documents/amber_PL_ML/CASF2016/all_opt_ligands_resp/'
foldernames = [i for i in os.listdir(direct1) if len(i) == 4]
dic_total = {}
for foldername in foldernames:
    #print (foldername)
    direct2 = direct1+foldername+'/'
    l_file = open(direct2+foldername+'_ligand_opt_resp_use.mol2', 'r').readlines()
    dic_c = get_connect(l_file)
    dic_atominfo = get_atominfo(l_file)
    if len(dic_c) != len(dic_atominfo):
        print ('error! Please check total atom number!')
        break
    dic_f = get_chemical_environment(dic_c, dic_atominfo)  
    if 'nf' in dic_f:
        print (foldername)
    dic_total = combine_dics(dic_total, dic_f)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    