import os
import json

direct1 = '/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/power_screening/'
fp1 = open(direct1+'TargetInfo.dat', 'r').readlines()

dic1 = {}
for line in fp1[9:]:
    newlist = []
    newlist = line.split()
    if newlist[0] in dic1:
        print ('error!')
    dic1[newlist[0]] = {}
    for i in range(1,len(newlist)):
        dic1[newlist[0]][str(i)] = newlist[i]

newfile = open('/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/screening_target_info.json', 'w')
json.dump(dic1, newfile)
newfile.close()


