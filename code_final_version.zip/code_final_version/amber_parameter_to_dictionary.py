#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 16:00:21 2019

@author: peijun
"""

import os
import json

#def same_atom_changer(m):
#    old = ['cc', 'ce', 'cg', 'cp', 'nc', 'ne', 'pc', 'pe']
#    new = ['cd', 'cf', 'ch', 'cq', 'nd', 'nf', 'pd', 'pf']
#    if m not in old:
#        return m
#    elif m in old:
#        ind = old.index(m)
#        new_m = new[ind]
#        return new_m
direct_f = '/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/'
fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/gaff2_bond.dat', 'r').readlines()
dic_bond = {}
for line in fp1:
    line = line.replace('-', ' ')
    newlist = []
    newlist = line.split()
    #newlist[0] = same_atom_changer(newlist[0])
    #newlist[1] = same_atom_changer(newlist[1])
    newbond1 = newlist[0]+'-'+newlist[1]
    newbond2 = newlist[1]+'-'+newlist[0]
    if newbond1 in dic_bond or newbond2 in dic_bond:
        print ('error! Same bond atom pair exists!', newbond1, newbond2)
    dic_bond[newbond1] = {}
    dic_bond[newbond1]['kb'] = round(float(newlist[2]), 1)
    dic_bond[newbond1]['r0'] = round(float(newlist[3]), 4)
#newfile1 = open(direct_f+'dic_bond.json', 'w')
#json.dump(dic_bond, newfile1)
#newfile1.close()
    
fp2 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/gaff2_angle.dat', 'r').readlines()
dic_angle = {}
for line in fp2:
    line = line.replace('-', ' ')
    newlist = []
    newlist = line.split()
    newangle1 = '-'.join([newlist[0], newlist[1], newlist[2]])
    newangle2 = '-'.join([newlist[2], newlist[1], newlist[0]])
    if newangle1 in dic_angle or newangle2 in dic_angle:
        print ('error! Same angle atom pair exists!', newangle1, newangle2)
    dic_angle[newangle1] = {}
    dic_angle[newangle1]['k-theta'] = round(float(newlist[3]), 1)
    dic_angle[newangle1]['theta0'] = round(float(newlist[4]), 2)
#newfile2 = open(direct_f+'dic_angle.json', 'w')
#json.dump(dic_angle, newfile2)
#newfile2.close()
    
fp3 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/gaff2_torsion.dat', 'r').readlines()
dic_torsion = {}
for line in fp3:
    line = line.replace('-', ' ')
    newlist = []
    newlist = line.split()
    newtorsion1 = '-'.join([newlist[0], newlist[1], newlist[2], newlist[3]])
    newtorsion2 = '-'.join([newlist[3], newlist[2], newlist[1], newlist[0]])
    if newtorsion2 in dic_torsion and newtorsion1 != newtorsion2:
        print ('error! Same torsion atom pair exists!', newtorsion1, newtorsion2, line)
    if newtorsion1 not in dic_torsion and newtorsion2 not in dic_torsion:
        dic_torsion[newtorsion1] = {}
        dic_torsion[newtorsion1]['divider'] = []
        dic_torsion[newtorsion1]['barrier'] = []
        dic_torsion[newtorsion1]['phase'] = []
        dic_torsion[newtorsion1]['periodicity'] = []
        dic_torsion[newtorsion1]['divider'].append(int(newlist[4]))
        dic_torsion[newtorsion1]['barrier'].append(round(float(newlist[5]), 3))
        dic_torsion[newtorsion1]['phase'].append(round(float(newlist[6]), 3))
        dic_torsion[newtorsion1]['periodicity'].append(round(float(newlist[7]), 3))
        continue
    if newtorsion1 != newtorsion2:
        if newtorsion1 in dic_torsion and newtorsion2 not in dic_torsion:
            dic_torsion[newtorsion1]['divider'].append(int(newlist[4]))
            dic_torsion[newtorsion1]['barrier'].append(round(float(newlist[5]), 3))
            dic_torsion[newtorsion1]['phase'].append(round(float(newlist[6]), 3))
            dic_torsion[newtorsion1]['periodicity'].append(round(float(newlist[7]), 3))
        elif newtorsion2 in dic_torsion:
            print (newtorsion2)
    elif newtorsion1 == newtorsion2:
        if newtorsion1 in dic_torsion:
            dic_torsion[newtorsion1]['divider'].append(int(newlist[4]))
            dic_torsion[newtorsion1]['barrier'].append(round(float(newlist[5]), 3))
            dic_torsion[newtorsion1]['phase'].append(round(float(newlist[6]), 3))
            dic_torsion[newtorsion1]['periodicity'].append(round(float(newlist[7]), 3))
#newfile2 = open(direct_f+'dic_dihedral.json', 'w')
#json.dump(dic_torsion, newfile2)
#newfile2.close()

fp4 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/gaff2_oop.dat', 'r').readlines()
dic_oop = {}
for line in fp4:
    line = line.replace('-', ' ')
    newlist = []
    newlist = line.split()
    newoop = '-'.join([newlist[0], newlist[1], newlist[2], newlist[3]])
    if newoop in dic_oop:
        print ('Same oop exists twice in dic_oop', newoop)
    dic_oop[newoop] = {}
    dic_oop[newoop]['barrier'] = round(float(newlist[4]), 1)
    dic_oop[newoop]['phase'] = int(newlist[5])
    dic_oop[newoop]['periodicity'] = int(newlist[6])
        
newfile2 = open(direct_f+'dic_oop.json', 'w')
json.dump(dic_oop, newfile2)
newfile2.close()
            


    
    
    
    
    
    
    
    
    
    
    
    