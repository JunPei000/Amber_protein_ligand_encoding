#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 09:50:03 2019

@author: peijun
"""

import os
from encode_amber_info_finder import atom_info_protein

direct1 = '/Users/peijun/Documents/mlproject_mac/jun_single_res_ff14sb/'
foldername = 'ALA'
fp1 = open(direct1+foldername+'/'+'min2.pdb', 'r').readlines()
dic_pro = atom_info_protein(fp1)

fp2 = open('/Users/peijun/Documents/amber_PL_ML/inter_energies_resp/1h23/1h23_protein_from_orig.pdb', 'r').readlines()
fp3 = open('/Users/peijun/Documents/amber_PL_ML/inter_energies_resp/1h23/protein_min1.pdb', 'r').readlines()

dic_pro1 = atom_info_protein(fp2)
dic_pro2 = atom_info_protein(fp3)