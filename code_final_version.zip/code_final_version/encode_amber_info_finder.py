#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 12:37:04 2019

@author: peijun
"""

import os
import json

def lig_info(ligfile):
    dic_lig = {}; dic_bond = {}; bond_list = []
    ind1 = 0; ind2 = 0
    ind1 = ligfile.index('@<TRIPOS>ATOM\n')
    ind2 = ligfile.index('@<TRIPOS>BOND\n')
    ind3 = ligfile.index('@<TRIPOS>SUBSTRUCTURE\n')
    for i in range(ind1+1, ind2):
        newlist = []
        if 'BACKBONE' in ligfile[i]:
            ligfile[i] = ligfile[i].replace('BACKBONE', '')
        newlist = ligfile[i].split()
        if newlist[0] in dic_lig:
            print ('Error! Same atom number exists twice in ligfile!')
        dic_lig[newlist[0]] = {}
        dic_lig[newlist[0]]['resp'] = round(float(newlist[-1]), 6)
        dic_lig[newlist[0]]['coor'] = [round(float(newlist[2]), 4), round(float(newlist[3]), 4), round(float(newlist[4]), 4)]
        dic_lig[newlist[0]]['amber_type'] = newlist[5]
    for i in range(ind2+1, ind3):
        newlist = []
        if 'BACKBONE' in ligfile[i]:
            ligfile[i] = ligfile[i].replace('BACKBONE', '')
        if '|DICT|INTERRES' in ligfile[i]:
            ligfile[i] = ligfile[i].replace('|DICT|INTERRES', '')
        newlist = ligfile[i].split()
        if len(newlist) != 4:
            print ('Error! Wrong bond information in ligfile!', ligfile[i])
        if newlist[1] not in dic_bond:
            dic_bond[newlist[1]] = []
        if newlist[2] not in dic_bond:
            dic_bond[newlist[2]] = []
        dic_bond[newlist[1]].append(newlist[2])
        dic_bond[newlist[2]].append(newlist[1])
    for key in dic_bond:
        for key1 in dic_bond[key]:
            newbond1 = key+'-'+key1
            newbond2 = key1+'-'+key
            if newbond1 not in bond_list and newbond2 not in bond_list:
                bond_list.append(newbond1)
    return dic_lig, dic_bond, bond_list

def angle_finder(dic_bond, bond_list):
    dic_angle = {}; angle_list = []
    
    for bond in bond_list:
        [atom1, atom2] = bond.split('-')
        for atom3 in dic_bond[atom1]:
            if atom3 == atom2:
                continue
            angle1 = '-'.join([atom3, atom1, atom2])
            angle2 = '-'.join([atom2, atom1, atom3])
            if angle1 not in angle_list and angle2 not in angle_list:
                angle_list.append(angle1)
        for atom3 in dic_bond[atom2]:
            if atom3 == atom1:
                continue
            angle1 = '-'.join([atom1, atom2, atom3])
            angle2 = '-'.join([atom3, atom2, atom1])
            if angle1 not in angle_list and angle2 not in angle_list:
                angle_list.append(angle1)
    for angle in angle_list:
        [atom1, atom2, atom3] = angle.split('-')
        if atom1 not in dic_angle:
            dic_angle[atom1] = []
        if atom3 not in dic_angle:
            dic_angle[atom3] = []
        dic_angle[atom1].append(atom3)
        dic_angle[atom3].append(atom1)
    return dic_angle, angle_list

def dihedral_finder(dic_bond, angle_list):
    dic_dihedral = {}; diheral_list = []
    
    for angle in angle_list:
        [atom1, atom2, atom3] = angle.split('-')
        for atom4 in dic_bond[atom1]:
            if atom4 == atom2 or atom4 == atom3:
                continue
            dihedral1 = '-'.join([atom4, atom1, atom2, atom3])
            dihedral2 = '-'.join([atom3, atom2, atom1, atom4])
            if dihedral1 not in diheral_list and dihedral2 not in diheral_list:
                diheral_list.append(dihedral1)
        for atom4 in dic_bond[atom3]:
            if atom4 == atom1 or atom4 == atom2:
                continue
            dihedral1 = '-'.join([atom1, atom2, atom3, atom4])
            dihedral2 = '-'.join([atom4, atom3, atom2, atom1])
            if dihedral1 not in diheral_list and dihedral2 not in diheral_list:
                diheral_list.append(dihedral1)
    for dihedral in diheral_list:
        [atom1, atom2, atom3, atom4] = dihedral.split('-')
        if atom1 not in dic_dihedral:
            dic_dihedral[atom1] = []
        if atom4 not in dic_dihedral:
            dic_dihedral[atom4] = []
        dic_dihedral[atom1].append(atom4)
        dic_dihedral[atom4].append(atom1)
        
    return dic_dihedral, diheral_list

def oop_finder(dic_bond, angle_list):
    oop_list = []
    
    for angle in angle_list:
        [atom1, atom2, atom3] = angle.split('-')
        for atom4 in dic_bond[atom2]:
            if atom4 != atom1 and atom4 != atom3:
                oop1 = '-'.join([atom4, atom1, atom2, atom3])
                oop2 = '-'.join([atom1, atom4, atom2, atom3])
                oop3 = '-'.join([atom3, atom4, atom2, atom1])
                oop4 = '-'.join([atom4, atom3, atom2, atom1])
                oop5 = '-'.join([atom1, atom3, atom2, atom4])
                oop6 = '-'.join([atom3, atom1, atom2, atom4])
                if oop1 not in oop_list and oop2 not in oop_list and oop3 not in oop_list and oop4 not in oop_list and oop5 not in oop_list and oop6 not in oop_list:
                    oop_list.append(oop1)
    
    return oop_list

def vdw_finder(dic_lig, dic_bond, dic_angle, dic_dihedral):
    vdw_list = []
    for i in range(1, len(dic_lig)+1):
        for j in range(i+1, len(dic_lig)+1):
            if (str(i) in dic_bond and str(j) in dic_bond[str(i)]) or (str(j) in dic_bond and str(i) in dic_bond[str(j)]):
                continue
            if (str(i) in dic_angle and str(j) in dic_angle[str(i)]) or (str(j) in dic_angle and str(i) in dic_angle[str(j)]):
                continue
            if (str(i) in dic_dihedral and str(j) in dic_dihedral[str(i)]) or (str(j) in dic_dihedral and str(i) in dic_dihedral[str(j)]):
                continue
            else:
                vdw1 = str(i)+'-'+str(j)
                vdw2 = str(j)+'-'+str(i)
                #if vdw1 not in vdw_list and vdw2 not in vdw_list:
                vdw_list.append(vdw1)
    return vdw_list



def decoy_lig_generator(decoy_lig, dic_lig):
    for key in dic_lig:
        if key not in decoy_lig:
            print ('Missing atom in decoy_lig!', key)
            continue
        decoy_lig[key]['resp'] = dic_lig[key]['resp']
        decoy_lig[key]['amber_type'] = dic_lig[key]['amber_type']
    return decoy_lig
            

### Protein info finder
def protein_prep(pdbfile):
    resi_ind = []; resi_num = 0; resi_name = 'ORG'; atom_names = []
    for i in range(len(pdbfile)):
        if len(pdbfile[i]) <10 or pdbfile[i][:4] != 'ATOM' or (int(pdbfile[i][22:26]) != resi_num and len(pdbfile[i]) >= 10):
            flagn = 0; flagc = 0
            for name in atom_names:
                if 'H1' in atom_names or 'H2' in atom_names or 'H3' in atom_names:
                    flagn = 1
                if 'OXT' in atom_names:
                    flagc = 1
            #print flagn, flagc, atom_names
            if flagn == 1 and flagc == 1:
                print ('One residue is both N and C terminals!', resi_name, resi_num)
            elif flagn == 1 and flagc == 0:
                for j in resi_ind:
                    pdbfile[j] = pdbfile[j][:17]+'N'+pdbfile[j][17:]
            elif flagn == 0 and flagc == 1:
                for j in resi_ind:
                    #print pdbfile[j]
                    pdbfile[j] = pdbfile[j][:17]+'C'+pdbfile[j][17:]
                    #print pdbfile[j]
            resi_name = pdbfile[i][17:20]
            resi_ind = []
            atom_names = []
        if len(pdbfile[i]) >= 26 and pdbfile[i][:4] == 'ATOM':
            resi_num = int(pdbfile[i][22:26])
            resi_ind.append(i)
            atom_names.append(pdbfile[i][11:17].replace(' ', ''))
        else:
            resi_num = 0
        
    return pdbfile
        
         


def atom_info_protein(pdbfile):
    dic1 = {}; dic_metal = {}
    metal = ['ZN', 'NA', 'MG', 'CA']
    count = 0
    for line in pdbfile:
        if 'ATOM'  in line:
            newlist = []
            newlist = line.split()
            key = newlist[1]+'_'+newlist[2]
            if newlist[2][0].isdigit():
                check_type = newlist[2][1]
            elif not newlist[2][0].isdigit():
                check_type = newlist[2][0]
            #if newlist[2] in metal and newlist[3] == newlist[2]:
                
            if newlist[2] == 'HNCA' or newlist[2] == 'HOCA':
                continue
            if len(newlist[4]) == 1:
                if key not in dic1 and check_type != 'P' and 'O1P' not in key and 'O2P' not in key and 'O3P' not in key:
                    dic1[key] = {}
                    dic1[key]['coor'] = []
                    if newlist[6].count('.') == 2:
                        a = []
                        a = check(newlist[6])
                        newlist[6] = a[0]
                        newlist.insert(7, a[1])
                    if newlist[6].count('.') == 3:
                        a = []
                        a = check(newlist[6])
                        newlist[6] = a[0]
                        newlist.insert(7, a[1])
                        newlist.insert(8, a[2])
                    if newlist[7].count('.') == 2 or newlist[7].count('.') == 3:
                        a = []
                        a = check(newlist[7])
                        newlist[7] = a[0]
                        newlist.insert(8, a[1])
                    dic1[key]['coor'].append(float(newlist[6]))
                    dic1[key]['coor'].append(float(newlist[7]))
                    dic1[key]['coor'].append(float(newlist[8]))
                    #dic1[key]['res_info'] = newlist[3]
                    #print newlist[2], newlist[3]
                    if newlist[2] not in metal or (newlist[2] in metal and newlist[3] != newlist[2]):
                        dic1[key]['amber_type'], dic1[key]['epsilon'], dic1[key]['Rmin'], dic1[key]['charge'] = amber_protein_atomtype(newlist[2], newlist[3])
                        dic1[key]['metal'] = 0
                    elif newlist[2] in metal and newlist[3] == newlist[2]:
                        dic1[key]['metal'] = 1
            elif len(newlist[4]) != 1:
                if key not in dic1:
                    dic1[key] = {}
                    dic1[key]['coor'] = []
                    if newlist[5].count('.') == 2:
                        a = []
                        a = check(newlist[5])
                        newlist[5] = a[0]
                        newlist.insert(6, a[1])
                    if newlist[5].count('.') == 3:
                        a = []
                        a = check(newlist[5])
                        newlist[5] = a[0]
                        newlist.insert(6, a[1])
                        newlist.insert(7, a[2])
                    if newlist[6].count('.') == 2 or newlist[6].count('.') == 3:
                        a = []
                        a = check(newlist[6])
                        newlist[6] = a[0]
                        newlist.insert(7, a[1])
                    dic1[key]['coor'].append(float(newlist[5]))
                    dic1[key]['coor'].append(float(newlist[6]))
                    dic1[key]['coor'].append(float(newlist[7]))
                    #dic1[key]['res_info'] = newlist[3]
                    #print newlist[2], newlist[3]
                    if newlist[2] not in metal or (newlist[2] in metal and newlist[3] != newlist[2]):
                        dic1[key]['amber_type'], dic1[key]['epsilon'], dic1[key]['Rmin'], dic1[key]['charge'] = amber_protein_atomtype(newlist[2], newlist[3])
                        dic1[key]['metal'] = 0
                    elif newlist[2] in metal and newlist[3] == newlist[2]:
                        dic1[key]['metal'] = 1
    return dic1

def check(m):
    parts = []
    while '.' in m:
        ind = 0
        ind = m.index('.')
        parts.append(m[:ind+4])
        m = m[ind+4:]
    return parts

def amber_protein_atomtype(atom, resi):
    fp2 = open('/Users/peijun/Documents/amber_PL_ML/code/ff14sb_para.json', 'r')
    amber_p = {}
    amber_p = json.load(fp2)
    
    if 'HIS' in resi:
        resi = resi.replace('HIS', 'HID')
    #if atom == 'OXT':
    #    resi = 'C'+resi
    #if atom == 'H1' or atom == 'H2' or atom == 'H3':
    #    atom = 'H'
    
    if atom == 'HB1' and ('LEU'  in resi or 'ASN' in resi or 'GLU' in resi or 'LYS' in resi or 'HID' in resi or 'SER' in resi or 'GLN' in resi):
        atom = 'HB3'
    if (atom == 'HG1' or atom == 'HG') and ('ARG' in resi or 'LYS' in resi or 'GLU' in resi or 'GLN' in resi):
        atom = 'HG3'
    if atom == 'HD1' and ('LYS' in resi or 'ARG' in resi):
        atom = 'HD3'
    atom_name = atom+'-'+resi
    if atom_name not in amber_p:
        print atom_name
    amber_type = amber_p[atom_name]['amber_type']
    epsilon = amber_p[atom_name]['epsilon']
    R_min = amber_p[atom_name]['Rmin']
    charge = amber_p[atom_name]['charge']
    return amber_type, epsilon, R_min, charge
    
    
    
    
    
            
    
    
        
    