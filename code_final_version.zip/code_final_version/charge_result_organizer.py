from __future__ import division
import os
import json
import pandas as pd
import matplotlib.pyplot as plt

direct1 = '/Users/peijun/Documents/amber_PL_ML/CASF2016/all_opt_ligands_resp/'
foldernames = [i for i in os.listdir(direct1) if len(i) == 4 and os.path.isdir(direct1+i)]
dic1 = {}
problem = ['3fcq', '4wiv', '4jsz', '4tmn', '4mme', '4hge', '1u1b', '4gr0', '3arp', '3lka', '1o0h', '4jia', '3ehy', '3myg', '2zcr', '4dli', '5tmn', '3qgy']
for foldername in foldernames:
    if foldername in problem:
        continue
    direct2 = direct1+foldername+'/'
    if foldername+'_ligand_opt_resp_use.mol2' not in os.listdir(direct2):
        print ('missing ligand file!')
    fp1 = open(direct2+foldername+'_ligand_opt_resp_use.mol2', 'r').readlines()
    ind1 = 0; ind2 = 0
    ind1 = fp1.index('@<TRIPOS>ATOM\n')
    ind2 = fp1.index('@<TRIPOS>BOND\n')
    if ind1 == 0 or ind2 == 0:
        print ('check file!', foldername)
    for i in range(ind1+1, ind2):
        newlist = []
        newlist = fp1[i].split()
        if newlist[-4] == 'cc':
            newlist[-4] = 'cd'
        elif newlist[-4] == 'ce':
            newlist[-4] = 'cf'
        elif newlist[-4] == 'cg':
            newlist[-4] = 'ch'
        elif newlist[-4] == 'cp':
            newlist[-4] = 'cq'
        elif newlist[-4] == 'nc':
            newlist[-4] = 'nd'
        elif newlist[-4] == 'ne':
            newlist[-4] = 'nf'
        elif newlist[-4] == 'pc':
            newlist[-4] = 'pd'
        elif newlist[-4] == 'pe':
            newlist[-4] = 'pf'
        if newlist[-4] not in dic1:
            dic1[newlist[-4]] = {}
            dic1[newlist[-4]]['charge'] = []
            dic1[newlist[-4]]['sysname'] = []
            dic1[newlist[-4]]['charge'].append(round(float(newlist[-1]), 4))
            dic1[newlist[-4]]['sysname'].append(foldername)
        elif newlist[-4] in dic1:
            if round(float(newlist[-1]), 4) not in dic1[newlist[-4]]:
                dic1[newlist[-4]]['charge'].append(round(float(newlist[-1]), 4))
                dic1[newlist[-4]]['sysname'].append(foldername)

s = 0; range_dic1 = {}
for key in dic1:
    s += len(dic1[key])
    range_dic1[key] = 0
    range_dic1[key] = max(dic1[key]['charge']) - min(dic1[key]['charge'])

for key in range_dic1:
    if range_dic1[key] >= 1:
        f_name1 = dic1[key]['sysname'][dic1[key]['charge'].index(max(dic1[key]['charge']))]
        f_name2 = dic1[key]['sysname'][dic1[key]['charge'].index(min(dic1[key]['charge']))]
        print (key, f_name1, max(dic1[key]['charge']), f_name2, min(dic1[key]['charge']))

for key in dic1:
    plt.figure()
    X = []
    Y = []
    mini = 0; maxi = 0
    mini = round(min(dic1[key]['charge'])-0.1, 1)
    maxi = round(max(dic1[key]['charge'])+0.1, 1)
    X = [i*0.1 for i in range(int(round(mini/0.1, 0)), int(round(maxi/0.1, 0)+1))]
    Y = [0 for i in X]
    for i in range(1, len(X)):
        for c in dic1[key]['charge']:
            if c <= X[i] and c > X[i-1]:
                Y[i] += 1
    if Y.count(0) == len(Y):
        print key
        break
    while Y[0] == 0:
        Y = Y[1:]
        X = X[1:]
    while Y[-1] == 0:
        Y = Y[:-1]
        X = X[:-1]
    plt.title(key)
    plt.xlabel('distance')
    plt.ylabel('count')
    plt.plot(X, Y, 'ro')
    plt.show()
    
        
        
        
        
        
        
        
        
        
        
        
        