#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 10:51:40 2019

@author: peijun
"""

import os
direct1 = '/Users/peijun/Documents/amber_PL_ML/inter_without_metal_resp/'
problem = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy','4dli', '5tmn', '3qgy']
problem = ['3ag9', '4gfm', 'list']
foldernames = [i for i in os.listdir(direct1) if len(i) == 4 and i not in problem]
newfile = open('/Users/peijun/Documents/amber_PL_ML/validation/resp/amber_complex_from_info_no_metal.txt', 'w')
#foldernames = ['1a30']
for foldername in foldernames:
    direct2 = direct1+foldername+'/'
    if 'protein_min1.out' not in os.listdir(direct2):
        print ('error! missing bond_info! Please check :', foldername)
    fp1 = open(direct2+'complex_min1.out', 'r').readlines()
    newlist1 = []; newlist2 = []; newlist3 = []
    for line in fp1:
        if 'BOND    =' in line and 'ANGLE   =' in line and 'DIHED      =' in line:
            newlist1 = line.split()
        elif 'VDWAALS =' in line:
            newlist2 = line.split()
        elif '1-4 VDW =' in line:
            newlist3 = line.split()
    newfile.write(foldername.ljust(10)+newlist1[2].ljust(20)+newlist1[5].ljust(20)+newlist1[8].ljust(20))
    newfile.write(newlist3[3].ljust(20)+newlist3[7].ljust(20))
    newfile.write(newlist2[2].ljust(20)+newlist2[5].ljust(20)+'\n')
newfile.close()
#for foldername in foldernames:
#    direct2 = direct1+foldername+'/'
#    if 'dihedral_info' in os.listdir(direct2):
#        fp1 = open(direct2+'dihedral_info', 'r').readlines()
#    elif 'dihedral_info.txt' in os.listdir(direct2):
#        fp1 = open(direct2+'dihedral_info.txt', 'r').readlines()
#    else:
#        print ('error! Cannot find dihedral_info file!', foldername)
#    energy = []
#    for line in fp1:
#        line = line.replace('(', ' ').replace(')', ' ').replace('M', ' ')
#        newlist = []
#        newlist = line.split()
#        #if len(newlist) == 19 or '|' in line:
#        #    continue
#        if len(newlist) <5:
#            continue
#        if newlist[0] != 'I':
#            continue
#        energy.append(float(newlist[-1]))
#    newfile.write(foldername.ljust(10)+str(sum(energy))+'\n')
#newfile.close()
    
            
