#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 10:31:36 2019

@author: peijun
"""

import os
import json

def bond_finder():
    
    
    
    
    
    
    
    
    
irect1 = '/Users/peijun/Documents/amber_PL_ML/CASF2016/all_opt_ligands_resp/'
direct2 = '/Users/peijun/Documents/amber_PL_ML/CASF-2016_orig/coreset/'
direct3 = '/Users/peijun/Documents/amber_PL_ML/CASF-2016_orig/decoys_docking/'
foldernames = [i for i in os.listdir(direct1) if len(i) == 4]
#foldernames = ['3bv9']
dic_inter = {}
#foldernames = ['1bcu']
for foldername in foldernames:
    print (foldername)
    dic_pro = {}; dic_resp = {}
    direct_r = direct1+foldername+'/'
    direct_p = direct2+foldername+'/'
    pdbfile = open(direct_p+foldername+'_protein.pdb', 'r').readlines()
    dic_pro = atom_info_protein(pdbfile)
    resp_lig = open(direct_r+foldername+'_ligand_opt_resp_use.mol2', 'r').readlines()
    dic_resp = resp_finder(resp_lig)
    decoy_lig = ligfile_finder(direct3, foldername)
    native_lig = native_finder(direct2, foldername)
    if len(native_lig) != 1:
        print ('error! More than one native ligand file exists! Please check :',foldername)
    for key in native_lig:
        if key not in decoy_lig:
            decoy_lig[key] = native_lig[key]
        elif key in decoy_lig:
            print ('error! Native ligand exists in decoy file! Please check :',foldername)
    dic_lig_total = {}
    dic_lig_total = atom_info_ligand(decoy_lig)
    dic_lig_final = charge_assign(dic_lig_total, dic_resp)
    for key in dic_lig_final:
        dic_temp = {}
        dic_temp = inter_m_finder(dic_pro, dic_lig_final[key])
        if key in dic_inter:
            print ('error! Same ligand structure exists!')
        dic_inter[key] = {}
        dic_inter[key] = dic_temp
    pd1 = pd.DataFrame.from_dict(dic_inter).T    