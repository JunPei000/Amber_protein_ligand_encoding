import os
import pandas as pd

direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/resp/screen/cutoff_10/'
foldernames = [i for i in os.listdir(direct1) if os.path.isdir(direct1+i)]

for foldername in foldernames:
    direct2 = direct1+foldername+'/'
    filenames = [i for i in os.listdir(direct2) if '.csv' in i]
    for filename in filenames:
        print (filename)
        df1 = pd.read_csv(direct2+filename)
        if len(df1.columns) == 8455:
            continue
        print ('error!', foldername)
        break




