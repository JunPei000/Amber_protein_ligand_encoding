#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 14:16:49 2019

@author: peijun
"""

import os

direct1 = '/Users/peijun/Documents/amber_PL_ML/energies_resp/'

problems = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy', '4dli', '5tmn', '3qgy']
foldernames = [i for i in os.listdir(direct1) if len(i) == 4 and i not in problems]
dic_change_angle = {}
dic_change_dihedral = {}
dic_change_oop = {}
#dic_change_oop['c3-ca-ca-nb'] = 'c3-ca-ca-n2'
#dic_change_oop['c3-cc-cc-nd'] = 'c3-ca-ca-n2'
center_atom = []
for foldername in foldernames:
    print (foldername)
    if foldername not in dic_change_oop:
        dic_change_oop[foldername] = {}
    direct2 = direct1+foldername+'/'
    filename = [i for i in os.listdir(direct2) if '.frcmod' in i and '.swp' not in i]
    if len(filename) != 1:
        print (foldername)
    
    fp1 = open(direct2+filename[0], 'r').readlines()
    ind1 = 0; ind2 = 0; ind3 = 0; ind4 = 0
    ind1 = fp1.index('ANGLE\n')
    ind2 = fp1.index('DIHE\n')
    ind3 = fp1.index('IMPROPER\n')
    ind4 = fp1.index('NONBON\n')
    
    for i in range(ind1+1, ind2-1):
        line = fp1[i].replace('-', ' ').replace(',', ' ')
        newlist = line.split()
        angle1 = '-'.join([newlist[0], newlist[1], newlist[2]])
        angle2 = '-'.join([newlist[2], newlist[1], newlist[0]])
        newangle1 = '-'.join([newlist[7], newlist[8], newlist[9]])
        newangle2 = '-'.join([newlist[9], newlist[8], newlist[7]])
        if angle1 not in dic_change_angle and angle2 not in dic_change_angle:
            dic_change_angle[angle1] = newangle1
        elif angle1 in dic_change_angle:
            if dic_change_angle[angle1] != newangle1 and dic_change_angle[angle1] != newangle2:
                print ('Same ange to different newangles!', angle1, dic_change_angle[angle1])
        elif angle2 in dic_change_angle:
            if dic_change_angle[angle2] != newangle1 and dic_change_angle[angle2] != newangle2:
                print ('Same ange to different newangles!', angle2, dic_change_angle[angle2])
        elif angle1 in dic_change_angle and angle2 in dic_change_angle and angle1 != angle2:
            print ('Same angle exists twice in dic_change_angle!', angle1, angle2)
            
    for i in range(ind2+1, ind3-1):
        line = fp1[i].replace('-', ' ').replace(',', ' ')
        newlist = line.split()
        dihedral1 = '-'.join([newlist[0], newlist[1], newlist[2], newlist[3]])
        dihedral2 = '-'.join([newlist[3], newlist[2], newlist[1], newlist[0]])
        newdihedral1 = '-'.join([newlist[10], newlist[11], newlist[12], newlist[13]])
        newdihedral2 = '-'.join([newlist[13], newlist[12], newlist[11], newlist[10]])
        if dihedral1 not in dic_change_dihedral and dihedral2 not in dic_change_dihedral:
            dic_change_dihedral[dihedral1] = newdihedral1
        elif dihedral1 in dic_change_dihedral:
            if dic_change_dihedral[dihedral1] != newdihedral1 and dic_change_dihedral[dihedral1] != newdihedral2:
                print ('Same dihedral to different newdihedrals!', dihedral1, dic_change_dihedral[dihedral1])
        elif dihedral2 in dic_change_dihedral:
            if dic_change_dihedral[dihedral2] != newdihedral1 and dic_change_dihedral[dihedral2] != newdihedral2:
                print ('Same dihedral to different newdihedrals!', dihedral2, dic_change_dihedral[dihedral2])
        elif dihedral1 in dic_change_dihedral and dihedral2 in dic_change_dihedral and dihedral1 != dihedral2:
            print ('Same dihedral exists twice in dic_change_dihedral!', dihedral1, dihedral2)
    
    for i in range(ind3+1, ind4-1):
        line = fp1[i].replace('-', ' ').replace(',', ' ')
        newlist = []
        newlist = line.split()
        oop1 = '-'.join([newlist[0], newlist[1], newlist[2], newlist[3]])
        #oop2 = '-'.join([newlist[1], newlist[0], newlist[2], newlist[3]])
        #oop3 = '-'.join([newlist[3], newlist[1], newlist[2], newlist[0]])
        #oop4 = '-'.join([newlist[1], newlist[3], newlist[2], newlist[0]])
        #oop5 = '-'.join([newlist[0], newlist[3], newlist[2], newlist[1]])
        #oop6 = '-'.join([newlist[3], newlist[0], newlist[2], newlist[1]])
       
       
        
        if oop1 not in dic_change_oop[foldername]:
            if 'Using general improper torsional angle' in line:
                dic_change_oop[foldername][oop1] = '-'.join([newlist[12], newlist[13], newlist[14], newlist[15]])
            elif 'Same as' in line:
                dic_change_oop[foldername][oop1] = '-'.join([newlist[9], newlist[10], newlist[11], newlist[12]])
            elif 'Using the default value' in line:
                dic_change_oop[foldername][oop1] = 'default'
        #if newlist[2] not in center_atom:
        #    center_atom.append(newlist[2])
        
        newoops = []
        #if 'Using general improper torsional angle' in line:
        #    newoop1 = '-'.join([newlist[12], newlist[13], newlist[14], newlist[15]])
        #    newoop2 = '-'.join([newlist[13], newlist[12], newlist[14], newlist[15]])
        #    newoop3 = '-'.join([newlist[13], newlist[15], newlist[14], newlist[12]])
        #    newoop4 = '-'.join([newlist[15], newlist[13], newlist[14], newlist[12]])
        #    newoop5 = '-'.join([newlist[12], newlist[15], newlist[14], newlist[13]])
        #    newoop6 = '-'.join([newlist[15], newlist[12], newlist[14], newlist[13]])
        #elif 'Same as' in line:
        #    newoop1 = '-'.join([newlist[9], newlist[10], newlist[11], newlist[12]])
        #    newoop2 = '-'.join([newlist[10], newlist[9], newlist[11], newlist[12]])
        #    newoop3 = '-'.join([newlist[12], newlist[10], newlist[11], newlist[9]])
        #    newoop4 = '-'.join([newlist[10], newlist[12], newlist[11], newlist[9]])
        #    newoop5 = '-'.join([newlist[9], newlist[12], newlist[11], newlist[10]])
        #    newoop6 = '-'.join([newlist[12], newlist[9], newlist[11], newlist[10]])
        #elif 'Using the default value' in line:
        #    newoop1 = 'default'
        #    newoop2 = 'default'
        #    newoop3 = 'default'
        #    newoop4 = 'default'
        #    newoop5 = 'default'
        #    newoop6 = 'default'
            #continue
            #newoop1 = '-'.join(['X', 'o', 'c', 'o'])
            #newoop2 = '-'.join(['X', 'o', 'c', 'o'])
            #newoop3 = '-'.join(['X', 'o', 'c', 'o'])
            #newoop4 = '-'.join(['X', 'o', 'c', 'o'])
            #newoop5 = '-'.join(['X', 'o', 'c', 'o'])
            #newoop6 = '-'.join(['X', 'o', 'c', 'o'])
        
        #newoops.append(newoop1)
        #newoops.append(newoop2)
        #newoops.append(newoop3)
        #newoops.append(newoop4)
        #newoops.append(newoop5)
        #newoops.append(newoop6)
        
        
        #if oop1 not in dic_change_oop and oop2 not in dic_change_oop and oop3 not in dic_change_oop and oop4 not in dic_change_oop and oop5 not in dic_change_oop and oop6 not in dic_change_oop:
        #    dic_change_oop[oop1] = newoop1
          #  dic_change_oop[oop1] = {}
          #  dic_change_oop[oop1]['barrier'] = round(float(newlist[4]), 1)
          #  dic_change_oop[oop1]['phase'] = round(float(newlist[5]), 1)
          #  dic_change_oop[oop1]['periodicity'] = round(float(newlist[6]), 1)
            
       # elif oop1 in dic_change_oop:
       #     if dic_change_oop[oop1]['barrier'] != round(float(newlist[4]), 1) or dic_change_oop[oop1]['phase'] != round(float(newlist[5]), 1) or dic_change_oop[oop1]['periodicity'] != round(float(newlist[6]), 1):
       #         print ('Same oop to different parameters!', oop1)
       # elif oop2 in dic_change_oop:
       #     if dic_change_oop[oop2]['barrier'] != round(float(newlist[4]), 1) or dic_change_oop[oop2]['phase'] != round(float(newlist[5]), 1) or dic_change_oop[oop2]['periodicity'] != round(float(newlist[6]), 1):
       #         print ('Same oop to different parameters!', oop2)
       # elif oop3 in dic_change_oop:
       #     if dic_change_oop[oop3]['barrier'] != round(float(newlist[4]), 1) or dic_change_oop[oop3]['phase'] != round(float(newlist[5]), 1) or dic_change_oop[oop3]['periodicity'] != round(float(newlist[6]), 1):
       #         print ('Same oop to different parameters!', oop3)
       # elif oop4 in dic_change_oop:
       #     if dic_change_oop[oop4]['barrier'] != round(float(newlist[4]), 1) or dic_change_oop[oop4]['phase'] != round(float(newlist[5]), 1) or dic_change_oop[oop4]['periodicity'] != round(float(newlist[6]), 1):
       #         print ('Same oop to different parameters!', oop4)
       # elif oop5 in dic_change_oop:
       #     if dic_change_oop[oop5]['barrier'] != round(float(newlist[4]), 1) or dic_change_oop[oop5]['phase'] != round(float(newlist[5]), 1) or dic_change_oop[oop5]['periodicity'] != round(float(newlist[6]), 1):
       #         print ('Same oop to different parameters!', oop5)
       # elif oop6 in dic_change_oop:
       #     if dic_change_oop[oop6]['barrier'] != round(float(newlist[4]), 1) or dic_change_oop[oop6]['phase'] != round(float(newlist[5]), 1) or dic_change_oop[oop6]['periodicity'] != round(float(newlist[6]), 1):
       #         print ('Same oop to different parameters!', oop6)
       # elif oop1 in dic_change_oop:
       #     if oop1 == 'c-c3-ns-hn' or oop1 == 'hn-ns-c3-c':
       #         continue
       #     if oop1 == 'c2-c3-c2-ha' or oop1 == 'ha-c2-c3-c2':
       #         continue
       #     if oop1 == 'c3-ca-ca-nb' or oop1 == 'nb-ca-ca-c3':
       #         continue
       #     if oop1 == 'c3-cc-cc-nd':
       #         continue
       #     elif dic_change_oop[oop1] not in newoops and dic_change_oop[oop1] == 'default':
       #         if '1.1          180.0         2.0' not in line:
       #             print ('Same oop to different newoop!', oop1, newoop1)
       # elif oop2 in dic_change_oop:
       #     if oop2 == 'c-c3-ns-hn' or oop2 == 'hn-ns-c3-c':
       #         continue
       #     if oop2 == 'c2-c3-c2-ha' or oop2 == 'ha-c2-c3-c2':
       #         continue
       #     if oop2 == 'c3-ca-ca-nb' or oop2 == 'nb-ca-ca-c3':
       #         continue
       #     if oop2 == 'c3-cc-cc-nd':
       #         continue
       #     elif dic_change_oop[oop2] not in newoops and dic_change_oop[oop2] == 'default':
       #         if '1.1          180.0         2.0' not in line:
       #             print ('Same oop to different newoop!', oop2, newoop1)
       # elif oop3 in dic_change_oop:
       #     if oop3 == 'c-c3-ns-hn' or oop3 == 'hn-ns-c3-c':
       #         continue
       #     if oop3 == 'c2-c3-c2-ha' or oop3 == 'ha-c2-c3-c2':
       #         continue
       #     if oop3 == 'c3-ca-ca-nb':
       #         continue
       #     if oop3 == 'c3-cc-cc-nd':
       #         continue
       #     elif dic_change_oop[oop3] not in newoops and dic_change_oop[oop3] == 'default':
       #         if '1.1          180.0         2.0' not in line:
       #             print ('Same oop to different newoop!', oop3, newoop1)
       # elif oop4 in dic_change_oop:
       #     if oop4 == 'c-c3-ns-hn' or oop4 == 'hn-ns-c3-c':
       #         continue
       #     if oop4 == 'c2-c3-c2-ha' or oop4 == 'ha-c2-c3-c2':
       #         continue
       #     if oop4 == 'c3-ca-ca-nb':
       #         continue
       #     if oop4 == 'c3-cc-cc-nd':
       #         continue
       #     elif dic_change_oop[oop4] not in newoops and dic_change_oop[oop4] == 'default':
       #         if '1.1          180.0         2.0' not in line:
       #             print ('Same oop to different newoop!', oop4, newoop1)
       # elif oop5 in dic_change_oop:
       #     if oop5 == 'c-c3-ns-hn' or oop5 == 'hn-ns-c3-c':
       #         continue
       #     if oop5 == 'c2-c3-c2-ha' or oop5 == 'ha-c2-c3-c2':
       #         continue
       #     if oop5 == 'c3-ca-ca-nb':
       #         continue
       #     if oop5 == 'c3-cc-cc-nd':
       #         continue
       #     elif dic_change_oop[oop5] not in newoops and dic_change_oop[oop5] == 'default':
       #         if '1.1          180.0         2.0' not in line:
       #             print ('Same oop to different newoop!', oop5, newoop1)
       # elif oop6 in dic_change_oop:
       #     if oop6 == 'c-c3-ns-hn' or oop6 == 'hn-ns-c3-c':
       #         continue
       #     if oop6 == 'c2-c3-c2-ha' or oop6 == 'ha-c2-c3-c2':
       #         continue
       #     if oop6 == 'c3-ca-ca-nb':
       #         continue
       #     if oop6 == 'c3-cc-cc-nd':
       #         continue
       #     elif dic_change_oop[oop6] not in newoops and dic_change_oop[oop6] == 'default':
       #         if '1.1          180.0         2.0' not in line:
       #             print ('Same oop to different newoop!', oop6, newoop1)
        
        
        
        
        
        
        
        
        
        
        
        
        
