import os
import json

direct1 = '/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/decoys_docking/'
problems = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy', '4dli', '5tmn', '3qgy']
filenames = [i for i in os.listdir(direct1) if '_rmsd.dat' in i and i[:4] not in problems]

dic1 = {}
for filename in filenames:
    fp1 = open(direct1+filename, 'r').readlines()[1:]
    rmsds = []; dic2 = {}
    for line in fp1:
        newlist = []
        newlist = line.split()
        rmsds.append(round(float(newlist[1]), 2))
        if newlist[0] in dic2:
            print ('error! Same molecule exists twice!', newlist[0])
        dic2[newlist[0]] = round(float(newlist[1]), 2)
    rmsds = sorted(rmsds)
    frmsds = [i for i in rmsds if i <= 1.0 and i != 0]
    names = []

    for key in dic2:
        if dic2[key] in frmsds:
            names.append(key)
    fnames = []
    #print (frmsds)
    if len(frmsds) == 0:
        continue
    for r in frmsds:
        tmp_names = []
        tmp_names = [i for i in names if i not in fnames]
        for n in tmp_names:
            if r == dic2[n]:
                fnames.append(n)
                break
    if len(fnames) != len(frmsds):
        print ('error!', fnames, frmsds)
    sysname = filename.replace('_rmsd.dat','')
    if sysname in dic1:
        print ('error! Same system exists twice!',filename)
    dic1[sysname] = {}
    if len(fnames) == 1:
        dic1[sysname]['1st'] = {}
        dic1[sysname]['1st']['rmsd'] = frmsds[0]
        dic1[sysname]['1st']['sysname'] = fnames[0]
    elif len(fnames) == 2:
        dic1[sysname]['1st'] = {}
        dic1[sysname]['1st']['rmsd'] = frmsds[0] 
        dic1[sysname]['1st']['sysname'] = fnames[0]

        dic1[sysname]['2nd'] = {}
        dic1[sysname]['2nd']['rmsd'] = frmsds[1]
        dic1[sysname]['2nd']['sysname'] = fnames[1]
    elif len(fnames) == 3:
        dic1[sysname]['1st'] = {}
        dic1[sysname]['1st']['rmsd'] = frmsds[0]
        dic1[sysname]['1st']['sysname'] = fnames[0]
        
        dic1[sysname]['2nd'] = {}
        dic1[sysname]['2nd']['rmsd'] = frmsds[1]
        dic1[sysname]['2nd']['sysname'] = fnames[1]

        dic1[sysname]['3rd'] = {}
        dic1[sysname]['3rd']['rmsd'] = frmsds[2]
        dic1[sysname]['3rd']['sysname'] = fnames[2]
    elif len(fnames) > 3:
        dic1[sysname]['1st'] = {}
        dic1[sysname]['1st']['rmsd'] = frmsds[0]
        dic1[sysname]['1st']['sysname'] = fnames[0]
        
        dic1[sysname]['2nd'] = {}
        dic1[sysname]['2nd']['rmsd'] = frmsds[1]
        dic1[sysname]['2nd']['sysname'] = fnames[1]

        dic1[sysname]['3rd'] = {}
        dic1[sysname]['3rd']['rmsd'] = frmsds[2]
        dic1[sysname]['3rd']['sysname'] = fnames[2]
   
        dic1[sysname]['others'] = {}
        dic1[sysname]['others']['rmsd'] = frmsds[3:]
        dic1[sysname]['others']['sysname'] = fnames[3:]
        
print (len(dic1))
newfile = open('/mnt/home/peijun/Documents/PL_amber/CASF-2016_orig/rmsd_info.json', 'w')
json.dump(dic1, newfile)
newfile.close()
