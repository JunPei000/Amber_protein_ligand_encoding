import os
import pandas as pd


direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/resp/final_cutoff_10/'

filenames = [i for i in os.listdir(direct1) if '.csv' in i and '.swp' not in i]
fp1 = open('/mnt/home/peijun/Documents/PL_amber/importance/feature_to_drop_for_500.txt', 'r').readlines()
feature_to_drop = []
feature_to_drop = fp1[0].split()
for filename in filenames:
    data = pd.read_csv(direct1+filename).drop(feature_to_drop, axis=1)
    #print (data)
    if 'Unnamed: 0.1' in data.columns:
        data = data.drop(['Unnamed: 0.1'], axis=1)
    if 'Unnamed: 0' in data.columns:
        data = data.drop(['Unnamed: 0'], axis=1)
    x_data = data.drop(['structure'], axis=1)
    y_data = data['structure'].map(lambda x: 0 if '000' in x else 1)
    TP = 0; FP = 0; TN = 0; FN = 0
    x_data['predicted'] = x_data.sum(axis=1)
    for row in x_data.index:
        if x_data.loc[row, 'predicted'] > 0:
            if data.loc[row, 'structure'][-3:] == '111':
                TP += 1
            elif data.loc[row, 'structure'][-3:] == '000':
                FP += 1
        elif x_data.loc[row, 'predicted'] < 0:
            if data.loc[row, 'structure'][-3:] == '111':
                FN += 1
            elif data.loc[row, 'structure'][-3:] == '000':
                TN += 1
    print (TP, TN, FP, FN)    










