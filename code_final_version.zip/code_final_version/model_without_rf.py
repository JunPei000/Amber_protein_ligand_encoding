import os
import pandas as pd


direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/resp/cutoff_10/'

filenames = [i for i in os.listdir(direct1) if '.csv' in i and '.swp' not in i]

for filename in filenames:
    






