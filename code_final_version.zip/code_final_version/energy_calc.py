#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 12:56:12 2019

@author: peijun
"""
from __future__ import division
import os
import json
from math import sqrt, pi, cos
import numpy as np

def distance(coor1, coor2):
    dist = 0
    dist = sqrt((coor1[0]-coor2[0])**2+(coor1[1]-coor2[1])**2+(coor1[2]-coor2[2])**2)
    dist = round(dist, 4)
    return dist

def angle_finder(coor1, coor2, coor3):
    angle = 0
    a = np.array(coor1)
    b = np.array(coor2)
    c = np.array(coor3)
    
    ba = a-b
    bc = c-b
    cosine_angle = np.dot(ba, bc)/(np.linalg.norm(ba)*np.linalg.norm(bc))
    angle = np.arccos(cosine_angle)
    
    return np.degrees(angle)

def dihedral_finder(p):
    """formula from Wikipedia article on "Dihedral angle"; formula was removed
    from the most recent version of article (no idea why, the article is a
    mess at the moment) but the formula can be found in at this permalink to
    an old version of the article:
    https://en.wikipedia.org/w/index.php?title=Dihedral_angle&oldid=689165217#Angle_between_three_vectors
    uses 1 sqrt, 3 cross products"""
    p0 = np.array(p[0])
    p1 = np.array(p[1])
    p2 = np.array(p[2])
    p3 = np.array(p[3])

    b0 = -1.0*(p1 - p0)
    b1 = p2 - p1
    b2 = p3 - p2

    b0xb1 = np.cross(b0, b1)
    b1xb2 = np.cross(b2, b1)

    b0xb1_x_b1xb2 = np.cross(b0xb1, b1xb2)

    y = np.dot(b0xb1_x_b1xb2, b1)*(1.0/np.linalg.norm(b1))
    x = np.dot(b0xb1, b1xb2)

    #if np.arctan2(y, x) < 0:
    #    return np.arctan2(y, x)+2*pi
    #else:
    #    return np.arctan2(y, x)
    return np.degrees(np.arctan2(y, x))

def bond_calc(dic_lig, bond_list):
    amber_bond = {}; bond_energy = {}
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_bond.json', 'r')
    amber_bond = json.load(fp1)
    
    for bond in bond_list:
        [atom1, atom2] = bond.split('-')
        atomtype1 = dic_lig[atom1]['amber_type']
        atomtype2 = dic_lig[atom2]['amber_type']
        coor1 = dic_lig[atom1]['coor']
        coor2 = dic_lig[atom2]['coor']
        dist_12 = distance(coor1, coor2)
        
        dic_change_atomtypes = {}
        dic_change_atomtypes['nx'] = 'n4'
        dic_change_atomtypes['ny'] = 'n4'
        dic_change_atomtypes['nz'] = 'n4'
        dic_change_atomtypes['nu'] = 'nh'
        dic_change_atomtypes['nv'] = 'nh'
        dic_change_atomtypes['n7'] = 'n3'
        dic_change_atomtypes['n8'] = 'n3'
        dic_change_atomtypes['ns'] = 'n'
        dic_change_atomtypes['nt'] = 'n'
        
        if atomtype1 in dic_change_atomtypes:
            atomtype1 = dic_change_atomtypes[atomtype1]
        if atomtype2 in dic_change_atomtypes:
            atomtype2 = dic_change_atomtypes[atomtype2]
        
        bond1 = atomtype1+'-'+atomtype2
        bond2 = atomtype2+'-'+atomtype1
        
        if bond1 not in amber_bond and bond2 not in amber_bond:
            if 'cz' in bond1:
                bond1 = bond1.replace('cz', 'c2')
                bond2 = bond2.replace('cz', 'c2')
            if bond1 not in amber_bond and bond2 not in amber_bond:
                print ('Cannot find bond in amber_bond!', bond1)
        kb = 0; b0 = 0
        
        if bond1 in amber_bond:
            kb = amber_bond[bond1]['kb']
            b0 = amber_bond[bond1]['r0']
        elif bond2 in amber_bond:
            kb = amber_bond[bond2]['kb']
            b0 = amber_bond[bond2]['r0']
        
        E_bond = 0
        E_bond = kb*(dist_12 - b0)**2
        if bond1 not in bond_energy and bond2 not in bond_energy:
            bond_energy[bond1] = E_bond
        elif (bond1 in bond_energy and bond2 not in bond_energy and bond1 != bond2) or (bond1 in bond_energy and bond1 == bond2):
            bond_energy[bond1] += E_bond
        elif (bond2 in bond_energy and bond1 not in bond_energy and bond1 != bond2):
            bond_energy[bond2] += E_bond
        elif bond1 in bond_energy and bond2 in bond_energy and bond1 != bond2:
            print ('Same bond exists twice in bond_energy!', bond1, bond2)

    return bond_energy
            

def angle_calc(dic_lig, angle_list):
    angle_energy = {}
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_angle.json', 'r')
    amber_angle = {}
    amber_angle = json.load(fp1)
    fp2 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_change_angle.json', 'r')
    dic_change_angle = {}
    dic_change_angle = json.load(fp2)
    
    
    
    amber_angle['p5-c3-s6'] = {}
    amber_angle['p5-c3-s6']['k-theta'] = 82.357     
    amber_angle['p5-c3-s6']['theta0'] = 110.675
    amber_angle['cd-os-n'] = {}
    amber_angle['cd-os-n']['k-theta'] = 87.6860   
    amber_angle['cd-os-n']['theta0'] = 107.5150
    amber_angle['n-c2-o'] = {}
    amber_angle['n-c2-o']['k-theta'] = 115.1660   
    amber_angle['n-c2-o']['theta0'] = 117.4601 
    amber_angle['oh-c3-n4'] = {}
    amber_angle['oh-c3-n4']['k-theta'] = 106.4040    
    amber_angle['oh-c3-n4']['theta0'] = 111.6100
    amber_angle['c3-ca-s6'] = {}
    amber_angle['c3-ca-s6']['k-theta'] = 65.001     
    amber_angle['c3-ca-s6']['theta0'] = 111.305
    amber_angle['os-ca-s6'] = {}
    amber_angle['os-ca-s6']['k-theta'] = 84.052         
    amber_angle['os-ca-s6']['theta0'] = 109.770 
    
    
    for angle in angle_list:
        [atom1, atom2, atom3] = angle.split('-')
        atomtype1 = dic_lig[atom1]['amber_type']
        atomtype2 = dic_lig[atom2]['amber_type']
        atomtype3 = dic_lig[atom3]['amber_type']
        coor1 = dic_lig[atom1]['coor']
        coor2 = dic_lig[atom2]['coor']
        coor3 = dic_lig[atom3]['coor']
        angle_degree = angle_finder(coor1, coor2, coor3)
        
        org_angle1 =  '-'.join([atomtype1, atomtype2, atomtype3])
        org_angle2 = '-'.join([atomtype3, atomtype2, atomtype1])
        angle1 = '-'.join([atomtype1, atomtype2, atomtype3])
        angle2 = '-'.join([atomtype3, atomtype2, atomtype1])
        
        if angle1 in dic_change_angle:
            angle1 = dic_change_angle[angle1]
            newlist = []
            newlist = angle1.split('-')
            angle2 = '-'.join([newlist[2], newlist[1], newlist[0]])
        elif angle2 in dic_change_angle:
            angle1 = dic_change_angle[angle2]
            newlist = []
            newlist = angle1.split('-')
            angle2 = '-'.join([newlist[2], newlist[1], newlist[0]])
        
        if angle1 not in amber_angle and angle2 not in amber_angle:
            print ('Cannot find angle in amber_angle!', angle1, angle2)
        
        k_theta = 0; theta0 = 0
        
        if angle1 in amber_angle:
            k_theta = amber_angle[angle1]['k-theta']
            theta0 = amber_angle[angle1]['theta0']
        elif angle2 in amber_angle:
            k_theta = amber_angle[angle2]['k-theta']
            theta0 = amber_angle[angle2]['theta0']
        
        E_angle = 0
        
        E_angle = k_theta*((angle_degree - theta0)/180*pi)**2
    
        if org_angle1 not in angle_energy and org_angle2 not in angle_energy:
            angle_energy[org_angle1] = E_angle
        elif (org_angle1 in angle_energy and org_angle2 not in angle_energy and org_angle1 != org_angle2) or (org_angle1 in angle_energy and org_angle1 == org_angle2):
            angle_energy[org_angle1] += E_angle
        elif org_angle2 in angle_energy and org_angle1 not in angle_energy and org_angle1 != org_angle2:
            angle_energy[org_angle2] += E_angle
        elif org_angle1 in angle_energy and org_angle2 in angle_energy and angle1 != angle2:
            print ('Same angle exists twice in angle_energy!', org_angle1, org_angle2)
    return angle_energy
            
            
def dihedral_calc(dic_lig, dihedral_list, angle_list):
    dihedral_energy = {}
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_dihedral.json', 'r')
    amber_diheral = {}
    amber_diheral = json.load(fp1)
    fp2 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_change_dihedral.json', 'r')
    dic_change_dihedral = {}
    dic_change_dihedral = json.load(fp2)  
    fp3 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/Rmin_epsilon.json', 'r')
    amber_nonb = {}
    amber_nonb = json.load(fp3)
    
    for dihedral in dihedral_list:
        [atom1, atom2, atom3, atom4] = dihedral.split('-')
        atomtype1 = dic_lig[atom1]['amber_type']
        atomtype2 = dic_lig[atom2]['amber_type']
        atomtype3 = dic_lig[atom3]['amber_type']
        atomtype4 = dic_lig[atom4]['amber_type']
        coor1 = dic_lig[atom1]['coor']
        coor2 = dic_lig[atom2]['coor']
        coor3 = dic_lig[atom3]['coor']
        coor4 = dic_lig[atom4]['coor']
        Rmin1 = amber_nonb[atomtype1]['Rmin']
        Rmin4 = amber_nonb[atomtype4]['Rmin']
        epsilon1 = amber_nonb[atomtype1]['epsilon']
        epsilon4 = amber_nonb[atomtype4]['epsilon']
        charge1 = dic_lig[atom1]['resp']
        charge4 = dic_lig[atom4]['resp']
        
        flag1 = 0; flag2 = 0       # Test if this dihedral is in 5 member ring or 6 member ring
        for angle in angle_list:
            [atom11, atom12, atom13] = angle.split('-')
            if (atom1 == atom11 and atom4 == atom13) or (atom1 == atom13 and atom4 == atom11):
                flag1 = 1
                break
        
        for dihedral_new in dihedral_list:
            if dihedral_new == dihedral:
                continue
            [atom11, atom12, atom13, atom14] = dihedral_new.split('-')
            if (atom1 == atom11 and atom4 == atom14) or (atom1 == atom14 and atom4 == atom11):
                flag2 += 1
            
        
        dihedral_degree = dihedral_finder([coor1, coor2, coor3, coor4])
        dist_14 = distance(coor1, coor4)
        
        org_dihedral1 = '-'.join([atomtype1, atomtype2, atomtype3, atomtype4])
        org_dihedral2 = '-'.join([atomtype4, atomtype3, atomtype2, atomtype1])
        dihedral1 = '-'.join([atomtype1, atomtype2, atomtype3, atomtype4])
        dihedral2 = '-'.join([atomtype4, atomtype3, atomtype2, atomtype1])
        newdihedral1 = '-'.join(['X', atomtype2, atomtype3, 'X'])
        newdihedral2 = '-'.join(['X', atomtype3, atomtype2, 'X'])
        
        if dihedral1 in dic_change_dihedral:
            dihedral1 = dic_change_dihedral[dihedral1]
            newlist = dihedral1.split('-')
            dihedral2 = '-'.join([newlist[3], newlist[2], newlist[1], newlist[0]])
            newdihedral1 = '-'.join(['X', newlist[1], newlist[2], 'X'])
            newdihedral2 = '-'.join(['X', newlist[2], newlist[1], 'X'])
        elif dihedral2 in dic_change_dihedral:
            dihedral1 = dic_change_dihedral[dihedral2]
            newlist = dihedral1.split('-')
            dihedral2 = '-'.join([newlist[3], newlist[2], newlist[1], newlist[0]])
            newdihedral1 = '-'.join(['X', newlist[1], newlist[2], 'X'])
            newdihedral2 = '-'.join(['X', newlist[2], newlist[1], 'X'])
        
        barrier = []; divider = []; phase = []; periodicity = []
        
        if dihedral1 in amber_diheral:
            barrier = amber_diheral[dihedral1]['barrier']
            divider = amber_diheral[dihedral1]['divider']
            phase = amber_diheral[dihedral1]['phase']
            periodicity = amber_diheral[dihedral1]['periodicity']
            
        elif dihedral2 in amber_diheral:
            barrier = amber_diheral[dihedral2]['barrier']
            divider = amber_diheral[dihedral2]['divider']
            phase = amber_diheral[dihedral2]['phase']
            periodicity = amber_diheral[dihedral2]['periodicity']
            
        elif dihedral1 not in amber_diheral and dihedral2 not in amber_diheral:
            
            if newdihedral1 in amber_diheral:
                barrier = amber_diheral[newdihedral1]['barrier']
                divider = amber_diheral[newdihedral1]['divider']
                phase = amber_diheral[newdihedral1]['phase']
                periodicity = amber_diheral[newdihedral1]['periodicity']
            elif newdihedral2 in amber_diheral:
                barrier = amber_diheral[newdihedral2]['barrier']
                divider = amber_diheral[newdihedral2]['divider']
                phase = amber_diheral[newdihedral2]['phase']
                periodicity = amber_diheral[newdihedral2]['periodicity']
            elif newdihedral1 not in amber_diheral and newdihedral2 not in amber_diheral:
                print ('Cannot find diheral in amber_dihedral!', dihedral1, newdihedral1)
        
        E_dihedral = 0; E_14_vdw = 0; E_14_eel = 0        
        for j in range(len(barrier)):
                E_dihedral += (float(barrier[j])/float(divider[j]))*(1+cos((float(periodicity[j])*dihedral_degree - phase[j])/180*pi))
        E_14_vdw = sqrt(epsilon1*epsilon4)*(((Rmin1+Rmin4)/dist_14)**12-2*((Rmin1+Rmin4)/dist_14)**6)
        E_14_eel = charge1*charge4*332.05/dist_14
        E_14_vdw = E_14_vdw/2
        E_14_eel = E_14_eel/1.2
        
        if flag1 != 0:
            E_14_vdw = 0
            E_14_eel = 0
        elif flag2 != 0 and flag1 == 0:
            E_14_vdw = E_14_vdw/(flag2+1)
            E_14_eel = E_14_eel/(flag2+1)
        #print org_dihedral1, dihedral_degree, E_dihedral
        if org_dihedral1 not in dihedral_energy and org_dihedral2 not in dihedral_energy:
            dihedral_energy[org_dihedral1] = {}
            dihedral_energy[org_dihedral1]['dihedral'] = E_dihedral
            dihedral_energy[org_dihedral1]['14_vdw'] = E_14_vdw
            dihedral_energy[org_dihedral1]['14_eel'] = E_14_eel
        elif (org_dihedral1 in dihedral_energy and org_dihedral2 not in dihedral_energy and org_dihedral1 != org_dihedral2) or (org_dihedral1 in dihedral_energy and org_dihedral1 == org_dihedral2):
            dihedral_energy[org_dihedral1]['dihedral'] += E_dihedral
            dihedral_energy[org_dihedral1]['14_vdw'] += E_14_vdw
            dihedral_energy[org_dihedral1]['14_eel'] += E_14_eel
        elif org_dihedral1 not in dihedral_energy and org_dihedral2 in dihedral_energy and org_dihedral1 != org_dihedral2:
            dihedral_energy[org_dihedral2]['dihedral'] += E_dihedral
            dihedral_energy[org_dihedral2]['14_vdw'] += E_14_vdw
            dihedral_energy[org_dihedral2]['14_eel'] += E_14_eel
        elif org_dihedral1 in dihedral_energy and org_dihedral2 in dihedral_energy and org_dihedral1 != org_dihedral2:
            print ('Error! Same dihedral exists twice in dihedral_energy!', org_dihedral1, org_dihedral2)

    return dihedral_energy

def check_oop(oopx, dic_change_oop):
    if dic_change_oop[oopx] == 'default':
        return 'D'
    oop1 = dic_change_oop[oopx]
    newlist = []
    newlist = oop1.split('-')
    oop2 = '-'.join([newlist[1], newlist[0], newlist[2], newlist[3]])
    oop3 = '-'.join([newlist[1], newlist[3], newlist[2], newlist[0]])
    oop4 = '-'.join([newlist[3], newlist[1], newlist[2], newlist[0]])
    oop5 = '-'.join([newlist[0], newlist[3], newlist[2], newlist[1]])
    oop6 = '-'.join([newlist[3], newlist[0], newlist[2], newlist[1]])
    
    newoop11 = '-'.join(['X', newlist[1], newlist[2], newlist[3]])
    newoop12 = '-'.join(['X', newlist[0], newlist[2], newlist[3]])
    newoop13 = '-'.join(['X', newlist[3], newlist[2], newlist[0]])
    newoop14 = '-'.join(['X', newlist[1], newlist[2], newlist[0]])
    newoop15 = '-'.join(['X', newlist[3], newlist[2], newlist[1]])
    newoop16 = '-'.join(['X', newlist[0], newlist[2], newlist[1]])
    
    newoop21 = '-'.join(['X', 'X', newlist[2], newlist[3]])
    newoop22 = '-'.join(['X', 'X', newlist[2], newlist[0]])
    newoop23 = '-'.join(['X', 'X', newlist[2], newlist[1]])
    
    
    
    return oop1, oop2, oop3, oop4, oop5, oop6, newoop11, newoop12, newoop13, newoop14, newoop15, newoop16, newoop21, newoop22, newoop23 
    
def oop_calc(dic_lig, oop_list, sysname):
    oop_energy = {}
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_oop.json', 'r')
    amber_oop = {}
    amber_oop = json.load(fp1)
    fp2 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/dic_change_oop.json', 'r')
    dic_change_oop = {}
    dic_change_oop_org = json.load(fp2)
    dic_change_oop = dic_change_oop_org[sysname]
    center_atom = ['c', 'ns', 'ca', 'nv', 'nt', 'ce', 'c2', 'cc', 'cd', 'n', 'na', 'nh', 'cp', 'nu', 'cf', 'cz', 'no', 'cq', 'n2']
    for oopn in oop_list:
        newlist_oop = []
        newlist_oop = oopn.split('-')
        [atom1, atom2, atom4] = sorted([int(i) for i in [newlist_oop[0], newlist_oop[1], newlist_oop[3]]])
        atom1 = str(atom1)
        atom2 = str(atom2)
        atom3 = newlist_oop[2]
        atom4 = str(atom4)
        
        atomtype1 = dic_lig[atom1]['amber_type']
        atomtype2 = dic_lig[atom2]['amber_type']
        atomtype3 = dic_lig[atom3]['amber_type']
        atomtype4 = dic_lig[atom4]['amber_type']
        coor1 = dic_lig[atom1]['coor']
        coor2 = dic_lig[atom2]['coor']
        coor3 = dic_lig[atom3]['coor']
        coor4 = dic_lig[atom4]['coor']
        oop_degree1 = dihedral_finder([coor1, coor2, coor3, coor4])
        oop_degree2 = dihedral_finder([coor1, coor4, coor3, coor2])
        oop_degree3 = dihedral_finder([coor2, coor1, coor3, coor4])
        oop_degree4 = dihedral_finder([coor2, coor4, coor3, coor1])
        oop_degree5 = dihedral_finder([coor4, coor1, coor3, coor2])
        oop_degree6 = dihedral_finder([coor4, coor2, coor3, coor1])
        
        
        oop_degreef = 0
        center_atom_type = atomtype3
        if atomtype3 not in oop_energy:
            oop_energy[atomtype3] = 0
            
        if atomtype3 not in center_atom:
            continue
        
        #print atom1, atom2, atom3, atom4, oop_degree1, oop_degree2, oop_degree3, oop_degree4, oop_degree5, oop_degree6
        oop1 = '-'.join([atomtype1, atomtype2, atomtype3, atomtype4])
        oop2 = '-'.join([atomtype1, atomtype4, atomtype3, atomtype2])
        oop3 = '-'.join([atomtype2, atomtype1, atomtype3, atomtype4])
        oop4 = '-'.join([atomtype2, atomtype4, atomtype3, atomtype1])
        oop5 = '-'.join([atomtype4, atomtype1, atomtype3, atomtype2])
        oop6 = '-'.join([atomtype4, atomtype2, atomtype3, atomtype1])
        
        if oop1 in dic_change_oop and dic_change_oop[oop1] != 'default':
            nn = dic_change_oop[oop1]
            newlist1 = []
            newlist1 = nn.split('-')
            atomtype1 = newlist1[0]
            atomtype2 = newlist1[1]
            atomtype3 = newlist1[2]
            atomtype4 = newlist1[3]
        elif oop2 in dic_change_oop and dic_change_oop[oop2] != 'default':
            nn = dic_change_oop[oop2]
            newlist1 = []
            newlist1 = nn.split('-')
            atomtype1 = newlist1[0]
            atomtype4 = newlist1[1]
            atomtype3 = newlist1[2]
            atomtype2 = newlist1[3]
        elif oop3 in dic_change_oop and dic_change_oop[oop3] != 'default':
            nn = dic_change_oop[oop3]
            newlist1 = []
            newlist1 = nn.split('-')
            atomtype2 = newlist1[0]
            atomtype1 = newlist1[1]
            atomtype3 = newlist1[2]
            atomtype4 = newlist1[3]
        elif oop4 in dic_change_oop and dic_change_oop[oop4] != 'default':
            nn = dic_change_oop[oop4]
            newlist1 = []
            newlist1 = nn.split('-')
            atomtype2 = newlist1[0]
            atomtype4 = newlist1[1]
            atomtype3 = newlist1[2]
            atomtype1 = newlist1[3]
        elif oop5 in dic_change_oop and dic_change_oop[oop5] != 'default':
            nn = dic_change_oop[oop5]
            newlist1 = []
            newlist1 = nn.split('-')
            atomtype4 = newlist1[0]
            atomtype1 = newlist1[1]
            atomtype3 = newlist1[2]
            atomtype2 = newlist1[3]
        elif oop6 in dic_change_oop and dic_change_oop[oop6] != 'default':
            nn = dic_change_oop[oop6]
            newlist1 = []
            newlist1 = nn.split('-')
            atomtype4 = newlist1[0]
            atomtype2 = newlist1[1]
            atomtype3 = newlist1[2]
            atomtype1 = newlist1[3]
        
        oop1 = '-'.join([atomtype1, atomtype2, atomtype3, atomtype4])
        oop2 = '-'.join([atomtype1, atomtype4, atomtype3, atomtype2])
        oop3 = '-'.join([atomtype2, atomtype1, atomtype3, atomtype4])
        oop4 = '-'.join([atomtype2, atomtype4, atomtype3, atomtype1])
        oop5 = '-'.join([atomtype4, atomtype1, atomtype3, atomtype2])
        oop6 = '-'.join([atomtype4, atomtype2, atomtype3, atomtype1])
        
        newoop11 = '-'.join(['X', atomtype1, atomtype3, atomtype2])
        newoop12 = '-'.join(['X', atomtype1, atomtype3, atomtype4])
        newoop13 = '-'.join(['X', atomtype2, atomtype3, atomtype1])
        newoop14 = '-'.join(['X', atomtype2, atomtype3, atomtype4])
        newoop15 = '-'.join(['X', atomtype4, atomtype3, atomtype1])
        newoop16 = '-'.join(['X', atomtype4, atomtype3, atomtype2])
        
        newoop21 = '-'.join(['X', 'X', atomtype3, atomtype1])
        newoop22 = '-'.join(['X', 'X', atomtype3, atomtype2])
        newoop23 = '-'.join(['X', 'X', atomtype3, atomtype4])
        
        
        
        
            
        barrier = 0; phase = 0; periodicity = 0

        if (oop1 in dic_change_oop and dic_change_oop[oop1] == 'default') or (oop2 in dic_change_oop and dic_change_oop[oop2] == 'default') or (oop3 in dic_change_oop and dic_change_oop[oop3] == 'default') or (oop4 in dic_change_oop and dic_change_oop[oop4] == 'default') or (oop5 in dic_change_oop and dic_change_oop[oop5] == 'default') or (oop6 in dic_change_oop and dic_change_oop[oop6] == 'default'):
            barrier = 1.1
            phase = 180
            periodicity = 2
            if oop1 in dic_change_oop:
                oop_degreef = oop_degree1
            elif oop2 in dic_change_oop:
                oop_degreef = oop_degree2
            elif oop3 in dic_change_oop:
                oop_degreef = oop_degree3
            elif oop4 in dic_change_oop:
                oop_degreef = oop_degree4
            elif oop5 in dic_change_oop:
                oop_degreef = oop_degree5
            elif oop6 in dic_change_oop:
                oop_degreef = oop_degree6
        if oop1 not in amber_oop and oop2 not in amber_oop and oop3 not in  amber_oop and oop4 not in amber_oop and oop5 not in amber_oop and oop6 not in amber_oop:
            if newoop11 not in amber_oop and newoop12 not in amber_oop and newoop13 not in amber_oop and newoop14 not in amber_oop and newoop15 not in  amber_oop and newoop16 not in amber_oop:
                if newoop21 not in amber_oop and newoop22 not in amber_oop and newoop23 not in amber_oop:
                    if barrier == 0 and phase == 0 and periodicity == 0:
                        print ('Cannot find oop in amber_oop!', oop1)
                        
                        
                        
        
        if oop1 in amber_oop:
            oopx = oop1
            oop_degreef = oop_degree1
        elif oop2 in amber_oop:
            oopx = oop2
            oop_degreef = oop_degree2
        elif oop3 in amber_oop:
            oopx = oop3
            oop_degreef = oop_degree3
        elif oop4 in amber_oop:
            oopx = oop4
            oop_degreef = oop_degree4
        elif oop5 in amber_oop:
            oopx = oop5
            oop_degreef = oop_degree5
        elif oop6 in amber_oop:
            oopx = oop6
            oop_degreef = oop_degree6
        elif oop1 not in amber_oop and oop2 not in amber_oop and oop3 not in  amber_oop and oop4 not in amber_oop and oop5 not in amber_oop and oop6 not in amber_oop:
            if newoop11 in amber_oop:
                oopx = newoop11
                oop_degreef = oop_degree5
            elif newoop12 in amber_oop:
                oopx = newoop12
                oop_degreef = oop_degree1
            elif newoop13 in amber_oop:
                oopx = newoop13
                oop_degreef = oop_degree6
            elif newoop14 in amber_oop:
                oopx = newoop14
                oop_degreef = oop_degree3
            elif newoop15 in amber_oop:
                oopx = newoop15
                oop_degreef = oop_degree4
            elif newoop16 in amber_oop:
                oopx = newoop16
                oop_degreef = oop_degree2
            elif newoop11 not in amber_oop and newoop12 not in amber_oop and newoop13 not in amber_oop and newoop14 not in amber_oop and newoop15 not in  amber_oop and newoop16 not in amber_oop:
                if newoop21 in amber_oop:
                    oopx = newoop21
                    #if int(atom1) < int(atom2):
                    oop_degreef = oop_degree4
                    #elif int(atom1) > int(atom2):
                    #    oop_degreef = oop_degree2
                elif newoop22 in amber_oop:
                    oopx = newoop22
                    #if int(atom2) < int(atom4):
                    oop_degreef = oop_degree2
                    #elif int(atom2) > int(atom4):
                    #    oop_degreef = oop_degree4
                elif newoop23 in amber_oop:
                    oopx = newoop23
                    #if int(atom1) < int(atom4):
                    oop_degreef = oop_degree1
                    #elif int(atom1) > int(atom4):
                    #    oop_degreef = oop_degree6
        if barrier == 0 and phase == 0 and periodicity == 0:
            barrier = amber_oop[oopx]['barrier']
            phase = amber_oop[oopx]['phase']
            periodicity = amber_oop[oopx]['periodicity']
            
        
        
        E_oop = 0
        E_oop = float(barrier)*(1+cos((float(periodicity)*oop_degreef - phase)/180*pi))
        
        #print oopn, oop1, oop_degreef, E_oop
        oop_energy[center_atom_type] += E_oop
            
    return oop_energy
    
def vdw_eel_calc(dic_lig, vdw_list):
    nonb_energy = {}
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/Rmin_epsilon.json', 'r')
    amber_nonb = {}
    amber_nonb = json.load(fp1)
    energy_info = []
    for nonb in vdw_list:
        [atom1, atom2] = nonb.split('-')
        
        atomtype1 = dic_lig[atom1]['amber_type']
        atomtype2 = dic_lig[atom2]['amber_type']
        coor1 = dic_lig[atom1]['coor']
        coor2 = dic_lig[atom2]['coor'] 
        
        Rmin1 = amber_nonb[atomtype1]['Rmin']
        Rmin2 = amber_nonb[atomtype2]['Rmin']
        epsilon1 = amber_nonb[atomtype1]['epsilon']
        epsilon2 = amber_nonb[atomtype2]['epsilon']
        charge1 = dic_lig[atom1]['resp']
        charge2 = dic_lig[atom2]['resp']
        
        dist = 0
        dist = distance(coor1, coor2)
        
        
        E_vdw = 0; E_eel = 0
        E_vdw = sqrt(epsilon1*epsilon2)*(((Rmin1+Rmin2)/dist)**12-2*((Rmin1+Rmin2)/dist)**6)
        E_eel = charge1*charge2*332.05/dist
        
        nonb1 = atomtype1+'-'+atomtype2
        nonb2 = atomtype2+'-'+atomtype1
        
        
        energy_info.append([E_vdw, E_eel])
        if nonb1 not in nonb_energy and nonb2 not in nonb_energy:
            nonb_energy[nonb1] = {}
            nonb_energy[nonb1]['vdw'] = E_vdw
            nonb_energy[nonb1]['eel'] = E_eel
        elif (nonb1 in nonb_energy and nonb2 not in  nonb_energy and nonb1 != nonb2) or (nonb1 in nonb_energy and nonb1 == nonb2):
            nonb_energy[nonb1]['vdw'] += E_vdw
            nonb_energy[nonb1]['eel'] += E_eel
        elif nonb2 in nonb_energy and nonb1 not in nonb_energy and nonb1 != nonb2:
            nonb_energy[nonb2]['vdw'] += E_vdw
            nonb_energy[nonb2]['eel'] += E_eel
        elif nonb1 in nonb_energy and nonb2 in nonb_energy and nonb1 != nonb2:
            print ('Same nonb exists twice in nonb_energy!', nonb1)
        
    return nonb_energy

def inter_calc(dic_lig, dic_pro):
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/Rmin_epsilon.json', 'r')
    amber_nonb = {}
    amber_nonb = json.load(fp1)
    
    inter_energy = {}; eel = []
    for key in dic_lig:
        for keyp in dic_pro:
            if dic_pro[keyp]['metal'] == 1:
                continue
            coorl = []; ccorp = []; 
            Rminl = 0; Rminp = 0; epsilonl = 0; epsilonp = 0; chargel = 0; chargep = 0
            atomtypel = dic_lig[key]['amber_type']
            coorl = dic_lig[key]['coor']
            chargel = dic_lig[key]['resp']
            Rminl = amber_nonb[atomtypel]['Rmin']
            epsilonl = amber_nonb[atomtypel]['epsilon']
            
            atomtypep = dic_pro[keyp]['amber_type']
            coorp = dic_pro[keyp]['coor']
            chargep = dic_pro[keyp]['charge']
            Rminp = dic_pro[keyp]['Rmin']
            epsilonp = dic_pro[keyp]['epsilon']
            
            dist = 0
            dist = distance(coorl, coorp)
            
            #if dist >= 9999:
            #    continue
            
            if dist >= 9999:
                continue
            
            E_vdw_inter = 0; E_eel_inter = 0
            
            E_vdw_inter = sqrt(epsilonl*epsilonp)*(((Rminl+Rminp)/dist)**12-2*((Rminl+Rminp)/dist)**6)
            E_eel_inter = chargel*chargep*332.05/dist
            eel.append([dist, chargel, chargep, E_eel_inter])
            
            nonb_inter = atomtypel+'-'+atomtypep
            if nonb_inter not in inter_energy:
                inter_energy[nonb_inter] = {}
                inter_energy[nonb_inter]['vdw'] = 0
                inter_energy[nonb_inter]['eel'] = 0
                
            inter_energy[nonb_inter]['vdw'] += E_vdw_inter
            inter_energy[nonb_inter]['eel'] += E_eel_inter
            
    return inter_energy
    
def metal_checker(dic_pro, dic_lig):
    fp1 = open('/Users/peijun/Documents/amber_PL_ML/gaff2_parameters/dictionary/Rmin_epsilon.json', 'r')
    amber_nonb = {}
    amber_nonb = json.load(fp1)
    
    inter_energy = {}; eel = []
    for key in dic_lig:
        for keyp in dic_pro:
            if dic_pro[keyp]['metal'] == 0:
                continue
            coorl = []; ccorp = []; 
            Rminl = 0; Rminp = 0; epsilonl = 0; epsilonp = 0; chargel = 0; chargep = 0
            atomtypel = dic_lig[key]['amber_type']
            coorl = dic_lig[key]['coor']
            
            coorp = dic_pro[keyp]['coor']
            
            dist = 0
            dist = distance(coorl, coorp)
            
            #if dist >= 9999:
            #    continue
            
            if dist <= 10:
                return 1
    return 0
    
    
    
    
    
            
            
            