#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 10:50:30 2019

@author: peijun
"""
import os
from encode_amber_info_finder import lig_info
from encode_amber_info_finder import angle_finder
from encode_amber_info_finder import dihedral_finder
from encode_amber_info_finder import oop_finder
from encode_amber_info_finder import vdw_finder
from encode_amber_info_finder import atom_info_protein
from encode_amber_info_finder import protein_prep
from energy_calc import bond_calc
from energy_calc import angle_calc
from energy_calc import dihedral_calc
from energy_calc import oop_calc
from energy_calc import vdw_eel_calc
from energy_calc import inter_calc
from energy_calc import metal_checker
from insert import insert

direct1 = '/Users/peijun/Documents/amber_PL_ML/CASF2016/all_opt_ligands_resp/resp_all_mol2/'
directp = '/Users/peijun/Documents/amber_PL_ML/CASF-2016_orig/coreset/'
problems = ['3fcq', '4jsz', '4tmn', '1u1b', '4gr0', '3lka', '3ehy', '4dli', '5tmn', '3qgy']
test = ['1h23', '1k1i', '1lpg', '2cbv', '2qbp', '2wbg', '2wer', '2xys', '2zy1', '3ary', '3b68', '3dx2', '3pww', '3up2', '3utu', '4abg', '4agp', '4eo8', '4f9w', '4kz6', '4qac', '5c2h']
filenames = [i for i in os.listdir(direct1) if '_ligand_opt_resp_use.mol2' in i and i[:4] not in problems and '.swp' not in i]
filenames = [i+'_ligand_opt_resp_use.mol2' for i in test]

#foldernames =['1ydr']
for filename in filenames:
    
    print (filename[:4], filenames.index(filename))
    
    ligfile = open(direct1+filename, 'r').readlines()
    dic_lig, dic_bond, bond_list = lig_info(ligfile)
    dic_angle, angle_list = angle_finder(dic_bond, bond_list)
    dic_dihedral, dihedral_list = dihedral_finder(dic_bond, angle_list)
    oop_list = oop_finder(dic_bond, angle_list)
    vdw_list = vdw_finder(dic_lig, dic_bond, dic_angle, dic_dihedral)
    
    #dic_bond_energy = bond_calc(dic_lig, bond_list)
    #dic_angle_energy = angle_calc(dic_lig, angle_list)
    #dic_dihedral_energy = dihedral_calc(dic_lig, dihedral_list, angle_list)
    #dic_oop_energy = oop_calc(dic_lig, oop_list, filename[:4])
    #dic_nonb_energy, energy_info = vdw_eel_calc(dic_lig, vdw_list)
    
    direct2 = '/Users/peijun/Documents/amber_PL_ML/inter_energies_resp/'+filename[:4]+'/'
    insert(direct2, direct2, 'protein_min1.pdb')
    protein_file = open('/Users/peijun/Documents/amber_PL_ML/inter_energies_resp/'+filename[:4]+'/inserted_protein_min1.pdb', 'r').readlines()
    #protein_file = open(directp+filename[:4]+'/'+filename[:4]+'_protein.pdb', 'r').readlines()
    #protein_file.append('END\n')
    protein_file = protein_prep(protein_file)
    dic_pro = atom_info_protein(protein_file)
    #flag = 0
    #for key in dic_pro:
    #    if dic_pro[key]['metal'] == 1:
    #        flag = 1
    #if flag == 0:
    #    continue
    
    #m = metal_checker(dic_pro, dic_lig)
    #if m == 1:
    #    print filename[:4]
    dic_inter_energy = inter_calc(dic_lig, dic_pro)
    
    test_vdw_inter = 0; test_eel_inter = 0
    
    for key in dic_inter_energy:
        test_vdw_inter += dic_inter_energy[key]['vdw']
        test_eel_inter += dic_inter_energy[key]['eel']
    print filename[:4], test_vdw_inter, test_eel_inter
    #test_vdw = 0; test_eel = 0
    #for key in dic_nonb_energy:
    #    test_vdw += dic_nonb_energy[key]['vdw']
    #    test_eel += dic_nonb_energy[key]['eel']
    #print filename[:4], test_vdw, test_eel
    
    #test_oop = 0
    #for key in dic_oop_energy:
    #    test_oop += dic_oop_energy[key]
    #print filename[:4], test_oop
    #test_dihedral = 0; test_14_vdw = 0; test_14_eel = 0
    #for key in dic_dihedral_energy:
    #    test_dihedral += dic_dihedral_energy[key]['dihedral']
    #    test_14_vdw += dic_dihedral_energy[key]['14_vdw']
    #    test_14_eel += dic_dihedral_energy[key]['14_eel']
    #print filename[:4], test_dihedral, test_14_vdw, test_14_eel
    #print test_dihedral, test_14_vdw, test_14_eel
    #test_angle = 0
    #for key in dic_angle_energy:
    #    test_angle += dic_angle_energy[key]
    #print test_angle
    #test_bond = 0
    #for key in dic_bond_energy:
    #    test_bond += dic_bond_energy[key]
    #print test_bond
    
