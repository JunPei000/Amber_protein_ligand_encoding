import os
import pandas as pd

direct1 = '/mnt/home/peijun/Documents/PL_amber/data_frame/resp/screen/cutoff_10/'
direct3 = '/mnt/home/peijun/Documents/PL_amber/data_frame/resp/screen/cutoff_10_modified/'
if not os.path.isdir(direct3):
    os.makedirs(direct3)
#done = '1o3f 3myg 4w9h 2cet 3ag9 5c2h 4jia 2p4y 3uex 3e93 5dwr 3gnw 4f3c 2al5 2fvd 3o9i 3nw9'.split()
foldernames = [i for i in os.listdir(direct1) if os.path.isdir(direct1+i)]


for foldername in foldernames:
    print (foldername)
    direct2 = direct1+foldername+'/'
    direct4 = direct3+foldername+'/'
    if not os.path.isdir(direct4):
        os.makedirs(direct4)
    filenames = [i for i in os.listdir(direct2) if '.csv' in i and '.swp' not in i]
    template = pd.read_csv('/mnt/home/peijun/Documents/PL_amber/template/cutoff_10_screen.csv')
    for filename in filenames:
        if filename in os.listdir(direct4):
            continue
        print (filename)
        pd1 = pd.read_csv(direct2+filename)
        for column in pd1:
            if 'Unnamed:' in column:
                continue
            for row in pd1.index:
                template.loc[row, column] = pd1.loc[row,column]
        template = template.fillna(0)
        newfile = open(direct4+filename, 'w')
        template.to_csv(newfile)
        newfile.close()


